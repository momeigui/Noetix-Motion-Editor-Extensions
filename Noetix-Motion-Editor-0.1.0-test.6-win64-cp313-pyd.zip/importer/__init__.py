"""导入后端：格式实现注册表。

约定：每个 backend 提供
    import_xx(context, filepath) -> list[Armature]
只负责"导入 + 返回新出现的骨架对象列表"，不处理命名/拆体/收编。

新增格式步骤：
1. 新建 xx_backend.py，实现同签名 import_xx；
2. 在本文件 _BACKENDS 注册 kind；
3. service 与 UI 零改动。
"""

from . import bvh_backend
from . import fbx_backend
from . import smpl_npz_backend

_BACKENDS = {
    "bvh": bvh_backend.import_bvh,
    "fbx": fbx_backend.import_fbx,
    "smpl_npz": smpl_npz_backend.import_smpl_npz,
}


def get_backend(kind):
    """按 kind 取导入函数；未知 kind 抛 ValueError。"""
    if kind not in _BACKENDS:
        raise ValueError(f"未知导入格式: {kind}")
    return _BACKENDS[kind]
