"""Noetix 生成数据的生命周期管理。

Blender 删除对象时不会自动删除其 Armature、Action、Mesh 等数据块。动作编辑
流程会反复导入、烘焙和重建预览，若只删对象，数百万关键帧的旧 Action 会继续
驻留内存。本模块只处理带 Noetix 管理标记的数据，绝不清理用户自己的未链接资产。
"""

import bpy

from . import constants as C


_PURGE_QUEUED = False


def mark_managed(*blocks):
    """标记由 Noetix 创建的数据块，供后续安全释放。"""
    for block in blocks:
        try:
            if block is not None:
                block[C.MANAGED_DATA_PROP] = True
        except ReferenceError:
            # 调用方可能正处于 Blender 自动释放某个临时数据块的边界；失效
            # 数据无需再登记，且绝不能反过来中断用户操作。
            continue


def _is_unused(block):
    """判断数据块是否只剩 fake user 或已完全没有使用者。"""
    users = getattr(block, "users", 0)
    return users == 0 or (getattr(block, "use_fake_user", False) and users <= 1)


def _remove_if_unused(collection, block):
    if block is None:
        return False
    try:
        if block.name not in collection:
            return False
        if not block.get(C.MANAGED_DATA_PROP) or not _is_unused(block):
            return False
        if hasattr(block, "use_fake_user"):
            block.use_fake_user = False
        collection.remove(block)
        return True
    except ReferenceError:
        # 同一轮清理中 Blender 可能已释放该 RNA 代理；它已不再占用数据，
        # 跳过即可，不能让清理阶段中断主操作。
        return False


def release_object(obj):
    """删除一个 Noetix 临时对象，并立即尝试释放其动作与几何数据。"""
    if obj is None or obj.name not in bpy.data.objects:
        return 0
    data = obj.data
    action = obj.animation_data.action if obj.animation_data else None
    bpy.data.objects.remove(obj, do_unlink=True)
    removed = 0
    for collection, block in (
        (bpy.data.actions, action),
        (bpy.data.armatures, data if getattr(data, "bl_rna", None) and data.bl_rna.identifier == "Armature" else None),
        (bpy.data.meshes, data if getattr(data, "bl_rna", None) and data.bl_rna.identifier == "Mesh" else None),
        (bpy.data.curves, data if getattr(data, "bl_rna", None) and data.bl_rna.identifier == "Curve" else None),
    ):
        removed += int(_remove_if_unused(collection, block))
    return removed


def purge_managed_orphans():
    """释放所有已失去引用的 Noetix 数据，返回删除总数。"""
    removed = 0
    # Action 可能带 fake user（SMPL 重定向预览会如此）；先解除它再删除。
    for collection in (
        bpy.data.actions,
        bpy.data.armatures,
        bpy.data.meshes,
        bpy.data.curves,
        bpy.data.materials,
    ):
        for block in list(collection):
            removed += int(_remove_if_unused(collection, block))
    return removed


def schedule_managed_orphan_purge():
    """操作栈退出后再回收未引用数据，避免 Blender Action 生命周期竞态。"""
    global _PURGE_QUEUED
    if _PURGE_QUEUED:
        return
    _PURGE_QUEUED = True
    bpy.app.timers.register(_run_scheduled_purge, first_interval=0.1)


def _run_scheduled_purge():
    global _PURGE_QUEUED
    try:
        purge_managed_orphans()
    except ReferenceError:
        # Blender 可能正在结束一次内部数据释放；下一次 Noetix 操作仍会再次
        # 排队清理，此处不应影响用户刚完成的动作转换。
        pass
    finally:
        _PURGE_QUEUED = False
    return None
