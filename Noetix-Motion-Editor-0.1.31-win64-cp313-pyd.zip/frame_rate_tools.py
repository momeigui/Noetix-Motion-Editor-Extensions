"""低帧率编辑与原始帧率交付。

编辑阶段将动作关键帧按时间比例压缩，例如 120 FPS -> 30 FPS 时缩为 1/4；
播放的实际秒数不变。导出阶段则临时恢复原始时间轴，令所有既有导出器仍按
原始采样率工作，结束后自动回到编辑视图。
"""

from contextlib import contextmanager
import math

import bpy
from bpy.props import IntProperty

from . import constants as C
from . import cleanup
from . import preview_align


def _source_for(armature):
    source_name = armature.get(C.SOURCE_NAME_PROP) if armature else None
    return bpy.data.objects.get(source_name) if source_name else None


def rate_owner(armature):
    """预览对象沿用其源 clone 的编辑速率配置。"""
    if armature is None:
        return None
    preview_source = armature.get(preview_align.PREVIEW_TAG)
    preview_owner = bpy.data.objects.get(preview_source) if preview_source else None
    return preview_owner if preview_owner is not None else armature


def source_fps(scene, armature):
    """获取导入速率，优先原生 NPZ/BVH 元数据，最后回退当前场景。"""
    owner = rate_owner(armature)
    if owner is None:
        return float(scene.render.fps / scene.render.fps_base)
    stored = owner.get(C.ORIGINAL_FPS_PROP)
    if stored is not None:
        return float(stored)
    source = _source_for(owner)
    for candidate in (owner, source):
        if candidate is None:
            continue
        value = candidate.get("noetix_smpl_fps")
        if value is not None:
            return float(value)
        frame_time = candidate.data.get(C.BVH_FRAME_TIME_PROP)
        if frame_time:
            return 1.0 / float(frame_time)
    return float(scene.render.fps / scene.render.fps_base)


def edit_fps(scene, armature):
    owner = rate_owner(armature)
    if owner is None:
        return source_fps(scene, armature)
    return float(owner.get(C.EDIT_FPS_PROP, source_fps(scene, owner)))


def is_low_rate_editing(scene, armature):
    owner = rate_owner(armature)
    if owner is None:
        return False
    return not math.isclose(
        float(owner.get(C.EDIT_TIME_SCALE_PROP, 1.0)), 1.0,
        rel_tol=1e-8, abs_tol=1e-8,
    )


def source_frame_for_edit(armature, edit_frame):
    """把编辑时间轴的帧号换算为原始源动作的采样帧号。

    归档源动作是不可变的输入；低帧率编辑只能缩放可编辑 clone。需要读取
    源姿势的 IK / 校验流程通过本函数换算时间，绝不能重写源 Action。
    """
    owner = rate_owner(armature)
    if owner is None:
        return float(edit_frame)
    scale = float(owner.get(C.EDIT_TIME_SCALE_PROP, 1.0))
    if math.isclose(scale, 1.0, rel_tol=1e-8, abs_tol=1e-8):
        return float(edit_frame)
    start = float(owner.get(C.ORIGINAL_FRAME_START_PROP, 1))
    return start + (float(edit_frame) - start) / scale


def _action_fcurves(action):
    layers = getattr(action, "layers", None)
    if not layers:
        return list(action.fcurves)
    curves = []
    for layer in layers:
        for strip in layer.strips:
            for bag in strip.channelbags:
                curves.extend(bag.fcurves)
    return curves


def _scale_action_time(action, factor, pivot):
    if action is None or math.isclose(factor, 1.0, rel_tol=1e-10, abs_tol=1e-10):
        return
    for curve in _action_fcurves(action):
        for key in curve.keyframe_points:
            key.co.x = pivot + (key.co.x - pivot) * factor
            key.handle_left.x = pivot + (key.handle_left.x - pivot) * factor
            key.handle_right.x = pivot + (key.handle_right.x - pivot) * factor
        curve.update()


def _relative_action_scale(action, reference_action):
    """根据两个动作的时间范围推测比例；仅用于恢复一次中断的转换。"""
    if action is None or reference_action is None:
        return None
    reference_start, reference_end = reference_action.frame_range
    action_start, action_end = action.frame_range
    reference_length = float(reference_end - reference_start)
    if abs(reference_length) <= 1e-8:
        return None
    return float((action_end - action_start) / reference_length)


def _resample_action_time_iter(owner, action, current_scale, target_scale, pivot, target_fps):
    """按目标编辑帧率重采样动作，只保留可编辑的整帧关键帧。

    单纯缩放曲线时间会把 120 FPS 的键变成 0.25 帧间隔；虽然时长正确，
    但编辑时依然会看到四倍密度的关键帧。这里从现有动作求值并新建 Action，
    以目标整数帧写回曲线。末帧无法整除时保留一个端点，避免时长被截短。
    """
    if action is None:
        return None
    if current_scale <= 0.0 or target_scale <= 0.0:
        raise ValueError("编辑帧率比例必须大于零")
    source_curves = list(_action_fcurves(action))
    if not source_curves:
        return (owner, action, action)

    start, end = action.frame_range
    target_start = pivot + (start - pivot) * (target_scale / current_scale)
    target_end = pivot + (end - pivot) * (target_scale / current_scale)
    # 导入动作的起帧是整数；仍使用 ceil/floor 兼容用户移动过动作的情况。
    first = math.ceil(target_start - 1e-6)
    last = math.floor(target_end + 1e-6)
    frames = [float(frame) for frame in range(first, last + 1)]
    if not frames or not math.isclose(frames[0], target_start, abs_tol=1e-5):
        frames.insert(0, float(target_start))
    if not math.isclose(frames[-1], target_end, abs_tol=1e-5):
        frames.append(float(target_end))

    # 先在旧 Action 仍绑定给 owner 时逐条采样。此前的实现会先替换绑定，
    # 再跨多个 modal tick 读取旧 FCurve；Blender 可能在某个 tick 间隙释放
    # 零用户 Action，下一次 ``curve.evaluate`` 就报 RNA 已删除。采样数据
    # 全部转为普通 Python 值后，才开始替换绑定和写入新 Action。
    sampled_curves = []
    sample_scale = current_scale / target_scale
    total = len(source_curves)
    for index, curve in enumerate(source_curves, start=1):
        sample_key = curve.keyframe_points[0] if curve.keyframe_points else None
        sampled_curves.append({
            "data_path": curve.data_path,
            "array_index": curve.array_index,
            "group_name": curve.group.name if curve.group is not None else "",
            "extrapolation": curve.extrapolation,
            "interpolation": sample_key.interpolation if sample_key is not None else None,
            "handle_left_type": sample_key.handle_left_type if sample_key is not None else None,
            "handle_right_type": sample_key.handle_right_type if sample_key is not None else None,
            "values": [curve.evaluate(pivot + (frame - pivot) * sample_scale) for frame in frames],
        })
        yield {"owner": owner.name, "done": index, "total": total, "stage": "采样"}

    # 此处之后不会再读取旧 Action 的任何 RNA 子对象。保留 fake user 只负责
    # 让取消时能恢复绑定；成功后由操作结束后的延迟清理回收旧动作。
    cleanup.mark_managed(action)
    kept_fake_user = getattr(action, "use_fake_user", False)
    if hasattr(action, "use_fake_user"):
        action.use_fake_user = True
    replacement = bpy.data.actions.new(f"{action.name}_edit_{int(round(target_fps))}")
    cleanup.mark_managed(replacement)
    animation = owner.animation_data_create()
    animation.action = replacement
    completed = False
    try:
        for index, sampled in enumerate(sampled_curves, start=1):
            replacement_curve = replacement.fcurve_ensure_for_datablock(
                owner,
                sampled["data_path"],
                index=sampled["array_index"],
                group_name=sampled["group_name"],
            )
            replacement_curve.extrapolation = sampled["extrapolation"]
            replacement_curve.keyframe_points.add(len(frames))
            coordinates = []
            for frame, value in zip(frames, sampled["values"]):
                coordinates.extend((frame, value))
            replacement_curve.keyframe_points.foreach_set("co", coordinates)
            # 保持原动作的插值风格；默认导入曲线使用 AUTO_CLAMPED，能避免
            # 低采样后 Bezier 把四肢摆动过冲。
            if sampled["interpolation"] is not None:
                for key in replacement_curve.keyframe_points:
                    key.interpolation = sampled["interpolation"]
                    key.handle_left_type = sampled["handle_left_type"]
                    key.handle_right_type = sampled["handle_right_type"]
            replacement_curve.update()
            yield {"owner": owner.name, "done": index, "total": total, "stage": "写入"}
        completed = True
        return (owner, action, replacement)
    finally:
        # Esc / 异常时必须恢复旧 Action；新 Action 尚未提交，不留下半成品。
        if not completed:
            if animation.action is replacement:
                animation.action = action
            if hasattr(action, "use_fake_user"):
                action.use_fake_user = kept_fake_user
            if replacement.users == 0:
                bpy.data.actions.remove(replacement)


def set_scene_fps(scene, fps):
    rounded = max(1, round(float(fps)))
    scene.render.fps = rounded
    scene.render.fps_base = rounded / float(fps)


def set_edit_fps_iter(context, armature, requested_fps):
    """分片切换编辑帧率；每条 FCurve 后 yield 一次以保持 UI 响应。"""
    if armature is None or armature.type != "ARMATURE" or not armature.get(C.CLONE_FLAG):
        raise ValueError("请先选中需要编辑的归一化骨架")
    if armature.get(preview_align.PREVIEW_TAG):
        raise ValueError("请选中原始 BVH/FBX/NPZ 骨架调整编辑帧率，不要选导出预览")
    requested_fps = float(requested_fps)
    if requested_fps <= 0:
        raise ValueError("编辑帧率必须大于零")
    scene = context.scene
    original_fps = float(armature.get(C.ORIGINAL_FPS_PROP, source_fps(scene, armature)))
    original_start = int(armature.get(C.ORIGINAL_FRAME_START_PROP, scene.frame_start))
    original_end = int(armature.get(C.ORIGINAL_FRAME_END_PROP, scene.frame_end))
    action = armature.animation_data.action if armature.animation_data else None
    if action is None:
        raise ValueError("当前骨架没有可编辑动作")
    source = _source_for(armature)
    source_action = (
        source.animation_data.action
        if source is not None and source.animation_data is not None
        else None
    )
    current_scale = float(armature.get(C.EDIT_TIME_SCALE_PROP, 1.0))
    # 若旧版本在替换 clone Action 后中断，状态属性尚未来得及写入。此时
    # 通过 clone / 归档源的动作长度恢复真实比例，避免再次把已经 30 FPS 的
    # clone 当作 120 FPS 重新压缩。
    if C.EDIT_TIME_SCALE_PROP not in armature:
        inferred_scale = _relative_action_scale(action, source_action)
        if inferred_scale is not None and inferred_scale > 0.0:
            current_scale = inferred_scale
    target_scale = requested_fps / original_fps
    if C.ORIGINAL_FPS_PROP not in armature:
        armature[C.ORIGINAL_FPS_PROP] = original_fps
        armature[C.ORIGINAL_FRAME_START_PROP] = original_start
        armature[C.ORIGINAL_FRAME_END_PROP] = original_end
    # 归档源骨架始终保留导入动作（原始帧率、原始时长）。IK 等读取源姿势
    # 的流程必须将编辑帧换算为源帧，不能为了对齐而重采样或改写源 Action。
    completed = []
    finished = False
    try:
        for label, owner, owner_action, owner_scale in (("编辑骨架", armature, action, current_scale),):
            # 已处于目标时间轴的动作无需重建；这也允许上一次在两套动作之间
            # 中断后保持当前已完成的编辑动作。
            if math.isclose(owner_scale, target_scale, rel_tol=1e-8, abs_tol=1e-8):
                continue
            job = _resample_action_time_iter(
                owner, owner_action, owner_scale, target_scale, original_start, requested_fps
            )
            while True:
                try:
                    progress = next(job)
                except StopIteration as stop:
                    if stop.value is not None:
                        completed.append(stop.value)
                    break
                if bpy.context.workspace is not None:
                    bpy.context.workspace.status_text_set(
                        f"正在{progress.get('stage', '转换')}{label}：{progress['done']} / {progress['total']} 条曲线（Esc 取消）"
                    )
                yield progress

        armature[C.EDIT_FPS_PROP] = requested_fps
        armature[C.EDIT_TIME_SCALE_PROP] = target_scale
        set_scene_fps(scene, requested_fps)
        scene.frame_start = original_start
        scene.frame_end = max(
            original_start,
            # 动作端点经缩放后可能落在非整数帧（例如 1722 @ 120 FPS
            # → 431.25 @ 30 FPS）。时间轴必须覆盖最后一个关键帧，不能用
            # round 把它截到 431，后续 IK 逐帧烘焙会遗漏尾帧。
            math.ceil(original_start + (original_end - original_start) * target_scale),
        )
        current = original_start + (scene.frame_current - original_start) * (target_scale / current_scale)
        scene.frame_set(min(max(round(current), scene.frame_start), scene.frame_end))
        context.view_layer.update()
        # 每个旧 Action 在替换前已登记并临时保留；不能在当前 generator /
        # Operator 栈仍持有旧 Action RNA 代理时直接
        # 删除它；延后到空闲回调清理，既保留自动回收，也避免 StructRNA
        # "Action has been removed" 生命周期错误。
        cleanup.schedule_managed_orphan_purge()
        finished = True
        return original_fps, requested_fps
    finally:
        if not finished:
            for owner, previous_action, replacement in reversed(completed):
                animation = owner.animation_data_create()
                if animation.action is replacement:
                    animation.action = previous_action
                if replacement is not previous_action and replacement.users == 0:
                    bpy.data.actions.remove(replacement)
        if bpy.context.workspace is not None:
            bpy.context.workspace.status_text_set(None)


def set_edit_fps(context, armature, requested_fps):
    """同步入口，供脚本和测试调用；UI 应使用分片生成器。"""
    job = set_edit_fps_iter(context, armature, requested_fps)
    try:
        while True:
            next(job)
    except StopIteration as stop:
        return stop.value
    finally:
        if bpy.context.workspace is not None:
            bpy.context.workspace.status_text_set(None)


@contextmanager
def export_at_source_rate(context, armature):
    """临时恢复导入速率和动作时间轴，供所有格式共用的交付采样。"""
    scene = context.scene
    owner = rate_owner(armature)
    if owner is None or not is_low_rate_editing(scene, owner):
        yield
        return
    action = armature.animation_data.action if armature.animation_data else None
    if action is None:
        yield
        return
    scale = float(owner.get(C.EDIT_TIME_SCALE_PROP, 1.0))
    original_fps = float(owner[C.ORIGINAL_FPS_PROP])
    original_start = int(owner[C.ORIGINAL_FRAME_START_PROP])
    original_end = int(owner[C.ORIGINAL_FRAME_END_PROP])
    previous = (
        scene.render.fps,
        scene.render.fps_base,
        scene.frame_start,
        scene.frame_end,
        scene.frame_current,
    )
    _scale_action_time(action, 1.0 / scale, original_start)
    set_scene_fps(scene, original_fps)
    scene.frame_start, scene.frame_end = original_start, original_end
    scene.frame_set(min(max(round(original_start + (previous[4] - original_start) / scale), original_start), original_end))
    context.view_layer.update()
    try:
        yield
    finally:
        _scale_action_time(action, scale, original_start)
        scene.render.fps, scene.render.fps_base = previous[0], previous[1]
        scene.frame_start, scene.frame_end = previous[2], previous[3]
        scene.frame_set(previous[4])
        context.view_layer.update()


def register_properties():
    if not hasattr(bpy.types.Scene, "noetix_edit_fps"):
        bpy.types.Scene.noetix_edit_fps = IntProperty(
            name="编辑帧率",
            description="低帧率编辑目标；应用后保持实际动画时长不变",
            default=30,
            min=1,
            max=1000,
        )


def unregister_properties():
    if hasattr(bpy.types.Scene, "noetix_edit_fps"):
        del bpy.types.Scene.noetix_edit_fps
