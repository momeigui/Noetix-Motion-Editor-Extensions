"""Noetix 在 Blender 偏好设置中的依赖检测与本地资源配置。"""

from pathlib import Path

import bpy
from bpy.props import StringProperty
from bpy.types import AddonPreferences

from . import constants as C
from . import dependencies


_DOWNLOAD_GUIDE_URL = (
    "https://noetixrobotics.feishu.cn/wiki/"
    "VUUTwQ2YfiuCGdkJOGac5hg8n2c?from=from_copylink"
)


def _default_smplh_directory():
    """默认指向插件相邻的 smplh 目录；用户可在偏好设置中改为本地模型目录。"""
    return str(Path(__file__).resolve().parents[1] / "smplh")


def _addon_preferences():
    """取得当前插件的偏好，兼容 Extension 的完整安装标识。

    开发版使用 ``noetix_motion_editor``，而 Blender Extension 实际保存偏好
    时会使用形如 ``bl_ext.<仓库>.<扩展 id>`` 的完整键。Pyd 模块在打包后
    的 ``__package__`` 在某些 Blender 构建中仅返回末段 id，直接按
    ``C.ADDON_ID`` 查询会失败并回退到会被更新替换的安装目录。
    """
    addons = bpy.context.preferences.addons
    for identifier in (C.ADDON_ID, __package__):
        addon = addons.get(identifier)
        if addon is not None and hasattr(addon.preferences, "smplh_directory"):
            return addon.preferences
    extension_id = C.ADDON_ID.rsplit(".", 1)[-1]
    for identifier, addon in addons.items():
        if (
            identifier.rsplit(".", 1)[-1] == extension_id
            and hasattr(addon.preferences, "smplh_directory")
        ):
            return addon.preferences
    return None


def smplh_directory():
    """供 NPZ 后端读取的已配置 SMPL-H 模型目录。"""
    preferences = _addon_preferences()
    configured = (
        preferences.smplh_directory
        if preferences is not None
        else _default_smplh_directory()
    )
    return Path(bpy.path.abspath(configured)).expanduser()


class NME_AddonPreferences(AddonPreferences):
    bl_idname = C.ADDON_ID

    smplh_directory: StringProperty(
        name="SMPL-H 模型目录",
        description="包含 male、female、neutral 子目录的本地 SMPL-H 模型路径",
        subtype="DIR_PATH",
        default=_default_smplh_directory(),
    )

    def draw(self, context):
        layout = self.layout
        update_notice = layout.box()
        update_notice.label(text="Pyd 扩展更新提示", icon="FILE_REFRESH")
        update_notice.label(text="更新完成后请重新启动 Blender，以加载新版本。")
        update_notice.label(text="若更新或卸载提示“拒绝访问”，请先关闭 Blender 后再操作。", icon="INFO")
        layout.separator()
        dependency_title = layout.row(align=True)
        dependency_title.label(text="依赖检测", icon="CHECKMARK")
        download = dependency_title.operator("wm.url_open", text="下载", icon="URL")
        download.url = _DOWNLOAD_GUIDE_URL
        state = dependencies.status()
        labels = {
            "bvh": "BVH 导入/导出（Blender 内置）",
            "better_fbx": "Better FBX Importer & Exporter",
        }
        for key in ("bvh", "better_fbx"):
            item = state[key]
            ok = item["installed"] and item["enabled"]
            row = layout.row()
            row.label(text=labels[key], icon="CHECKMARK" if ok else "ERROR")
            if ok:
                text = "正常"
            elif item.get("builtin"):
                text = "不可用"
            elif not item["installed"]:
                text = "未安装"
            elif item.get("import_available") or item.get("export_available"):
                text = "导入/导出功能不完整"
            else:
                text = "未启用"
            row.label(text=text)

        layout.separator()
        model_title = layout.row(align=True)
        model_title.label(text="SMPL-H 本地模型", icon="FILE_FOLDER")
        download = model_title.operator("wm.url_open", text="下载", icon="URL")
        download.url = _DOWNLOAD_GUIDE_URL
        layout.prop(self, "smplh_directory")
        models = dependencies.smplh_model_status(smplh_directory())
        for gender, available in models.items():
            row = layout.row()
            row.label(
                text=f"{gender}/model.npz",
                icon="CHECKMARK" if available else "ERROR",
            )
            row.label(text="正常" if available else "未找到")
        layout.label(text="SMPL-H 资源须由用户按授权自行取得，不随插件分发", icon="INFO")
