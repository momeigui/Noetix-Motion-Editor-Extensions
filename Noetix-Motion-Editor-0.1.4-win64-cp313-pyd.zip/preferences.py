"""Noetix 在 Blender 偏好设置中的依赖检测与本地资源配置。"""

from pathlib import Path

import bpy
from bpy.props import StringProperty
from bpy.types import AddonPreferences

from . import constants as C
from . import dependencies


_DOWNLOAD_GUIDE_URL = (
    "https://noetixrobotics.feishu.cn/wiki/"
    "VUUTwQ2YfiuCGdkJOGac5hg8n2c?from=from_copylink"
)


def _default_smplh_directory():
    """默认指向插件相邻的 smplh 目录；用户可在偏好设置中改为本地模型目录。"""
    return str(Path(__file__).resolve().parents[1] / "smplh")


def smplh_directory():
    """供 NPZ 后端读取的已配置 SMPL-H 模型目录。"""
    addon = bpy.context.preferences.addons.get(C.ADDON_ID)
    configured = addon.preferences.smplh_directory if addon is not None else _default_smplh_directory()
    return Path(bpy.path.abspath(configured)).expanduser()


class NME_AddonPreferences(AddonPreferences):
    bl_idname = C.ADDON_ID

    smplh_directory: StringProperty(
        name="SMPL-H 模型目录",
        description="包含 male、female、neutral 子目录的本地 SMPL-H 模型路径",
        subtype="DIR_PATH",
        default=_default_smplh_directory(),
    )

    def draw(self, context):
        layout = self.layout
        update_notice = layout.box()
        update_notice.label(text="Pyd 扩展更新提示", icon="FILE_REFRESH")
        update_notice.label(text="更新完成后请重新启动 Blender，以加载新版本。")
        update_notice.label(text="若更新或卸载提示“拒绝访问”，请先关闭 Blender 后再操作。", icon="INFO")
        layout.separator()
        dependency_title = layout.row(align=True)
        dependency_title.label(text="依赖检测", icon="CHECKMARK")
        download = dependency_title.operator("wm.url_open", text="下载", icon="URL")
        download.url = _DOWNLOAD_GUIDE_URL
        state = dependencies.status()
        labels = {
            "bvh": "BVH 扩展（io_anim_bvh）",
            "better_fbx": "Better FBX Importer & Exporter",
        }
        for key in ("bvh", "better_fbx"):
            item = state[key]
            ok = item["installed"] and item["enabled"]
            row = layout.row()
            row.label(text=labels[key], icon="CHECKMARK" if ok else "ERROR")
            row.label(text="正常" if ok else ("未安装" if not item["installed"] else "未启用"))

        layout.separator()
        model_title = layout.row(align=True)
        model_title.label(text="SMPL-H 本地模型", icon="FILE_FOLDER")
        download = model_title.operator("wm.url_open", text="下载", icon="URL")
        download.url = _DOWNLOAD_GUIDE_URL
        layout.prop(self, "smplh_directory")
        models = dependencies.smplh_model_status(smplh_directory())
        for gender, available in models.items():
            row = layout.row()
            row.label(
                text=f"{gender}/model.npz",
                icon="CHECKMARK" if available else "ERROR",
            )
            row.label(text="正常" if available else "未找到")
        layout.label(text="SMPL-H 资源须由用户按授权自行取得，不随插件分发", icon="INFO")
