"""时间线手势交互模块：
- 支持 Alt + 空格（默认推荐，零冲突原生播放）、纯空格、Shift + 空格
- 按住快捷键移动鼠标：快速拖动/刷帧时间线（Scrubbing）
- 按住快捷键 + 按住左键移动鼠标：直接框选所选骨骼的关键帧（及可选时间线预览范围）
"""

import time
import blf
import bpy
import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader
from bpy.props import BoolProperty, EnumProperty, FloatProperty
from bpy.types import Operator


_ADDON_KEYMAPS = []

# 拖拽期间跟随鼠标的帧号/区间提示；绘制回调只读取这份状态
_OVERLAY = {
    "active": False,
    "mouse": (0, 0),
    "frame": 0,
    "anchor": None,
    "sensitivity_until": 0.0,
}
_SENSITIVITY_HINT_SECONDS = 1.5
_SENSITIVITY_MIN = 1.0
_SENSITIVITY_MAX = 50.0


# 框选时鼠标停顿多久才真正写入关键帧选中状态
_SELECTION_APPLY_DELAY = 0.12
_OVERLAY_HANDLES = []
_OVERLAY_SPACE_TYPES = {"VIEW_3D", "DOPESHEET_EDITOR", "GRAPH_EDITOR"}


def _on_settings_updated(self, context):
    sync_keymaps()


def _resolve_scene():
    # 启动注册阶段 bpy.context / bpy.data 为受限对象，没有 scene / scenes
    scene = getattr(bpy.context, "scene", None)
    if scene:
        return scene
    scenes = getattr(bpy.data, "scenes", None)
    if scenes:
        return scenes[0]
    return None


def sync_keymaps():
    """按场景当前配置动态同步快捷键绑定状态与组合键修饰符。"""
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    scene = _resolve_scene()
    enabled = bool(getattr(scene, "noetix_enable_space_scrub", True)) if scene else True
    modifier = str(getattr(scene, "noetix_space_scrub_modifier", "ALT_SPACE")) if scene else "ALT_SPACE"

    for km, kmi in _ADDON_KEYMAPS:
        kmi.active = enabled
        kmi.type = "SPACE"
        if modifier == "ALT_SPACE":
            kmi.alt = True
            kmi.shift = False
            kmi.ctrl = False
        elif modifier == "SHIFT_SPACE":
            kmi.alt = False
            kmi.shift = True
            kmi.ctrl = False
        else:  # "SPACE" 仅空格
            kmi.alt = False
            kmi.shift = False
            kmi.ctrl = False


def _iter_action_fcurves(action, slot=None):
    """兼容 Blender 5.2 Layered Action 与 legacy fcurves；给定 slot 时只取该槽位的曲线。"""
    if action is None:
        return
    layers = getattr(action, "layers", None)
    if layers:
        for layer in layers:
            for strip in layer.strips:
                bag = strip.channelbag(slot) if slot is not None and hasattr(strip, "channelbag") else None
                if bag is not None:
                    yield from bag.fcurves
                elif slot is None:
                    for bag in strip.channelbags:
                        yield from bag.fcurves
    elif hasattr(action, "fcurves"):
        yield from action.fcurves


def get_bone_fcurves(fcurves, bone_names):
    """从曲线列表中筛出指定骨骼的 FCurves；未指定骨骼时返回全部。"""
    if not bone_names:
        return list(fcurves)
    prefixes = tuple(f'pose.bones["{b}"].' for b in bone_names)
    return [fc for fc in fcurves if fc.data_path.startswith(prefixes)]


def _tag_animation_editors_redraw(context):
    """刷新时间线、动画摄影表与曲线编辑器视口。"""
    if not context or not context.screen:
        return
    for area in context.screen.areas:
        if area.type in {"DOPESHEET_EDITOR", "TIMELINE", "GRAPH_EDITOR"}:
            area.tag_redraw()


def _draw_rect(x0, y0, x1, y1, color):
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    batch = batch_for_shader(
        shader,
        "TRIS",
        {"pos": ((x0, y0), (x1, y0), (x1, y1), (x0, y1))},
        indices=((0, 1, 2), (0, 2, 3)),
    )
    shader.uniform_float("color", color)
    batch.draw(shader)


def _draw_range_band(region, start_f, end_f):
    """在 Dopesheet / 曲线编辑器中高亮当前框选的帧区间。"""
    view2d = getattr(region, "view2d", None)
    if view2d is None:
        return
    x0, _ = view2d.view_to_region(start_f, 0, clip=False)
    x1, _ = view2d.view_to_region(end_f, 0, clip=False)
    x0 = max(-1.0, min(float(x0), region.width + 1.0))
    x1 = max(-1.0, min(float(x1), region.width + 1.0))
    _draw_rect(x0, 0, x1, region.height, (1.0, 0.6, 0.15, 0.12))
    edge = (1.0, 0.6, 0.15, 0.85)
    _draw_rect(x0 - 1, 0, x0 + 1, region.height, edge)
    _draw_rect(x1 - 1, 0, x1 + 1, region.height, edge)


def _draw_cursor_label(region, local_x, local_y, text, accent):
    scale = bpy.context.preferences.system.ui_scale
    font_id = 0
    blf.size(font_id, 15 * scale)
    text_w, text_h = blf.dimensions(font_id, text)
    pad_x, pad_y = 8 * scale, 5 * scale
    offset = 18 * scale
    box_w = text_w + pad_x * 2
    box_h = text_h + pad_y * 2

    # 默认放在光标右上方，靠近区域边缘时翻到另一侧
    x = local_x + offset
    if x + box_w > region.width - 4:
        x = local_x - offset - box_w
    y = local_y + offset
    if y + box_h > region.height - 4:
        y = local_y - offset - box_h
    x = max(4, x)
    y = max(4, y)

    _draw_rect(x, y, x + box_w, y + box_h, (0.08, 0.08, 0.08, 0.85))
    _draw_rect(x, y, x + 3 * scale, y + box_h, (*accent, 1.0))
    blf.color(font_id, *accent, 1.0)
    blf.position(font_id, x + pad_x, y + pad_y, 0)
    blf.draw(font_id, text)


def _draw_scrub_overlay():
    if not _OVERLAY["active"]:
        return
    context = bpy.context
    region = context.region
    space = context.space_data
    if region is None or space is None:
        return

    frame = _OVERLAY["frame"]
    anchor = _OVERLAY["anchor"]
    gpu.state.blend_set("ALPHA")
    try:
        if anchor is not None and space.type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}:
            _draw_range_band(region, min(anchor, frame), max(anchor, frame))

        mouse_x, mouse_y = _OVERLAY["mouse"]
        local_x = mouse_x - region.x
        local_y = mouse_y - region.y
        # 只在鼠标所在区域绘制提示框
        if not (0 <= local_x <= region.width and 0 <= local_y <= region.height):
            return
        if anchor is None:
            text = f"第 {frame} 帧"
            accent = (1.0, 1.0, 1.0)
        else:
            start_f, end_f = min(anchor, frame), max(anchor, frame)
            text = f"{start_f} - {end_f}  ({end_f - start_f + 1} 帧)"
            accent = (1.0, 0.6, 0.15)
        # 滚轮调整灵敏度后短暂附带显示当前值
        if time.time() < _OVERLAY["sensitivity_until"]:
            sensitivity = getattr(context.scene, "noetix_space_scrub_sensitivity", 6.0)
            text += f"  |  灵敏度 {sensitivity:.1f}"
        _draw_cursor_label(region, local_x, local_y, text, accent)
    finally:
        gpu.state.blend_set("NONE")


def _add_overlay():
    _remove_overlay()
    for space_cls in (bpy.types.SpaceView3D, bpy.types.SpaceDopeSheetEditor, bpy.types.SpaceGraphEditor):
        handle = space_cls.draw_handler_add(_draw_scrub_overlay, (), "WINDOW", "POST_PIXEL")
        _OVERLAY_HANDLES.append((space_cls, handle))
    _OVERLAY["active"] = True


def _remove_overlay():
    _OVERLAY["active"] = False
    for space_cls, handle in _OVERLAY_HANDLES:
        try:
            space_cls.draw_handler_remove(handle, "WINDOW")
        except (ValueError, RuntimeError):
            pass
    _OVERLAY_HANDLES.clear()


def _tag_overlay_redraw(context):
    if not context or not context.screen:
        return
    for area in context.screen.areas:
        if area.type in _OVERLAY_SPACE_TYPES:
            area.tag_redraw()


class KeyframeRangeSelector:
    """框选关键帧：清空整个动作的选中，只选中目标曲线在区间内的关键帧。

    每次通过 RNA 改关键帧选中都会把整个 Action 标记为待同步，
    下一次 frame_set 会复制全部关键帧（大段动捕上每步几十毫秒）。
    因此拖动中 set_range 只做 numpy 计算，apply 才写入，由调用方在停顿/松开时触发；
    首次 apply 时才快照并清空原选中，按下左键不会卡顿。
    """

    _SELECT_PROPS = ("select_control_point", "select_left_handle", "select_right_handle")

    def __init__(self, target_fcurves, all_fcurves):
        self._all_fcurves = all_fcurves
        # 首次 apply 前为 None；之后保存各曲线原控制点选中，供 ESC / 右键回退
        self.original_selection = None
        self.dirty = False

        # 不预读全部帧号（大段动捕上要上百毫秒），区间边界按需在关键帧上查找
        # [曲线, 关键帧数, 已写入区间起点, 已写入区间终点, 目标区间起点, 目标区间终点]
        self.targets = []
        for fc in target_fcurves:
            count = len(fc.keyframe_points)
            if count:
                self.targets.append([fc, count, 0, 0, 0, 0])

    def _snapshot_and_clear(self):
        self.original_selection = []
        for fc in self._all_fcurves:
            kps = fc.keyframe_points
            count = len(kps)
            if count == 0:
                continue
            selected = np.empty(count, dtype=bool)
            kps.foreach_get("select_control_point", selected)
            if not selected.any():
                continue
            self.original_selection.append((fc, selected))
            cleared = np.zeros(count, dtype=bool)
            for prop in self._SELECT_PROPS:
                kps.foreach_set(prop, cleared)

    @staticmethod
    def _bound(kps, count, value, hint):
        """返回首个帧号 > value 的索引；从上次结果附近步进，跳得远时退回二分查找。"""
        i = min(max(hint, 0), count)
        for _ in range(8):
            if i > 0 and kps[i - 1].co.x > value:
                i -= 1
            elif i < count and kps[i].co.x <= value:
                i += 1
            else:
                return i
        low, high = 0, count
        while low < high:
            mid = (low + high) // 2
            if kps[mid].co.x <= value:
                low = mid + 1
            else:
                high = mid
        return low

    @staticmethod
    def _set_selected(kps, indices, value):
        for i in indices:
            kp = kps[i]
            kp.select_control_point = value
            kp.select_left_handle = value
            kp.select_right_handle = value

    def set_range(self, start_frame, end_frame):
        """只计算区间对应的关键帧索引，不写入；返回区间内关键帧总数。"""
        s_f = min(start_frame, end_frame) - 1e-3
        e_f = max(start_frame, end_frame) + 1e-3
        total = 0
        for entry in self.targets:
            kps = entry[0].keyframe_points
            # 帧号均为整数附近，s_f/e_f 已偏移 1e-3，“首个 > s_f”即区间起点
            i_start = self._bound(kps, entry[1], s_f, entry[4])
            i_end = self._bound(kps, entry[1], e_f, entry[5])
            if (i_start, i_end) != (entry[4], entry[5]):
                entry[4], entry[5] = i_start, i_end
                self.dirty = True
            total += i_end - i_start
        if self.original_selection is None:
            self.dirty = True
        return total

    def apply(self):
        """把目标区间写入关键帧选中状态，只改动与上次写入相比变化的关键帧。"""
        if not self.dirty:
            return False
        if self.original_selection is None:
            self._snapshot_and_clear()
        for entry in self.targets:
            fc, _count, p_start, p_end, i_start, i_end = entry
            if (p_start, p_end) == (i_start, i_end):
                continue
            kps = fc.keyframe_points
            # 新旧区间都是连续索引段，只处理两者的差集
            self._set_selected(kps, range(p_start, min(p_end, i_start)), False)
            self._set_selected(kps, range(max(p_start, i_end), p_end), False)
            self._set_selected(kps, range(i_start, min(i_end, p_start)), True)
            self._set_selected(kps, range(max(i_start, p_end), i_end), True)
            entry[2], entry[3] = i_start, i_end
        self.dirty = False
        return True

    def update_range(self, start_frame, end_frame):
        total = self.set_range(start_frame, end_frame)
        self.apply()
        return total

    def restore_original(self):
        if self.original_selection is None:
            return
        restored = set()
        for fc, selected in self.original_selection:
            kps = fc.keyframe_points
            if len(kps) != len(selected):
                continue
            for prop in self._SELECT_PROPS:
                kps.foreach_set(prop, selected)
            restored.add(id(fc))
        # 原本无选中但被框选写入过的曲线需要清回去
        for entry in self.targets:
            fc = entry[0]
            if id(fc) in restored or entry[2] == entry[3]:
                continue
            cleared = np.zeros(len(fc.keyframe_points), dtype=bool)
            for prop in self._SELECT_PROPS:
                fc.keyframe_points.foreach_set(prop, cleared)


class NME_OT_space_scrub_timeline(Operator):
    """时间线拖拽与骨骼关键帧选区框选操作符。"""

    bl_idname = "noetix_motion_editor.space_scrub_timeline"
    bl_label = "时间线手势拖拽"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        scene = context.scene
        if not getattr(scene, "noetix_enable_space_scrub", True):
            return {"PASS_THROUGH"}

        modifier = getattr(scene, "noetix_space_scrub_modifier", "ALT_SPACE")

        # 特别优化：如果是单按空格模式且当前动画正在播放，按空格代表“立即暂停”，直接停止并退出
        if modifier == "SPACE" and context.screen and context.screen.is_animation_playing:
            bpy.ops.screen.animation_play()
            return {"FINISHED"}

        area = context.area
        if area and area.type not in {"VIEW_3D", "DOPESHEET_EDITOR", "TIMELINE"}:
            return {"PASS_THROUGH"}

        self._modifier = modifier
        self._start_time = time.time()
        self._was_playing = bool(context.screen and context.screen.is_animation_playing)
        if self._was_playing:
            bpy.ops.screen.animation_play()

        self._initial_frame = scene.frame_current
        self._initial_use_preview = scene.use_preview_range
        self._initial_preview_start = scene.frame_preview_start
        self._initial_preview_end = scene.frame_preview_end
        self._initial_frame_start = scene.frame_start
        self._initial_frame_end = scene.frame_end

        self._start_x = event.mouse_x
        self._last_x = event.mouse_x
        self._start_y = event.mouse_y
        self._last_y = event.mouse_y
        self._accumulated_dx = 0.0
        self._total_drag_distance = 0.0
        self._dragged = False
        self._lmb_held = False
        self._need_mouse_sync = False
        self._is_shift = False
        self._range_anchor_frame = None

        # 识别当前选中的骨骼名称
        active = context.active_object
        # 姿态模式下有选中骨骼时只框选这些骨骼，否则框选全部骨骼的关键帧
        self._target_bone_names = []
        if active and active.type == "ARMATURE" and context.mode == "POSE" and context.selected_pose_bones:
            self._target_bone_names = [b.name for b in context.selected_pose_bones]

        self._keyframe_selector = None
        self._selected_key_count = 0
        self._last_range_change = 0.0
        self._timer = context.window_manager.event_timer_add(0.05, window=context.window)

        if context.window:
            context.window.cursor_modal_set("SCROLL_X")

        _add_overlay()
        self._sync_overlay(context, event)
        self._update_status(context)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _sync_overlay(self, context, event):
        _OVERLAY["mouse"] = (event.mouse_x, event.mouse_y)
        _OVERLAY["frame"] = context.scene.frame_current
        _OVERLAY["anchor"] = self._range_anchor_frame if self._lmb_held else None
        _tag_overlay_redraw(context)

    def _apply_selection(self, context):
        if self._keyframe_selector and self._keyframe_selector.apply():
            _tag_animation_editors_redraw(context)

    def _cleanup(self, context):
        self._lmb_held = False
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        _remove_overlay()
        _tag_overlay_redraw(context)
        if context.window:
            context.window.cursor_modal_restore()
        if context.workspace and hasattr(context.workspace, "status_text_set"):
            context.workspace.status_text_set(None)

    def _update_status(self, context):
        if not (context.workspace and hasattr(context.workspace, "status_text_set")):
            return

        cur_frame = context.scene.frame_current
        target_mode = getattr(context.scene, "noetix_scrub_range_target", "KEYFRAMES")
        key_label = (
            "Alt+空格"
            if self._modifier == "ALT_SPACE"
            else ("Shift+空格" if self._modifier == "SHIFT_SPACE" else "空格")
        )

        if self._lmb_held and self._range_anchor_frame is not None:
            start_f = min(self._range_anchor_frame, cur_frame)
            end_f = max(self._range_anchor_frame, cur_frame)
            count = end_f - start_f + 1

            if target_mode == "PREVIEW":
                context.workspace.status_text_set(
                    f"【预览范围框选】{start_f} ~ {end_f}（共 {count} 帧） | 当前帧: {cur_frame} | 释放{key_label}完成"
                )
            else:
                bone_desc = "全部骨骼"
                if self._target_bone_names:
                    if len(self._target_bone_names) <= 3:
                        bone_desc = ", ".join(self._target_bone_names)
                    else:
                        bone_desc = f"{self._target_bone_names[0]} 等 {len(self._target_bone_names)} 根骨骼"
                context.workspace.status_text_set(
                    f"【选中骨骼关键帧】[{bone_desc}] {start_f} ~ {end_f} 帧（已选中 {self._selected_key_count} 个关键点） | 松开左键确认"
                )
        else:
            context.workspace.status_text_set(
                f"【时间线拖拽】当前第 {cur_frame} 帧 | 按住左键: 框选骨骼关键帧 | 滚轮: 灵敏度 "
                f"{getattr(context.scene, 'noetix_space_scrub_sensitivity', 6.0):.1f} | Shift: 精细 | Ctrl: 快进 | 松开{key_label}完成"
            )

    def modal(self, context, event):
        target_mode = getattr(context.scene, "noetix_scrub_range_target", "KEYFRAMES")
        self._is_shift = bool(event.shift)

        # 1. 鼠标左键：框选骨骼关键帧
        if event.type == "LEFTMOUSE":
            if event.value == "PRESS":
                self._lmb_held = True
                self._range_anchor_frame = context.scene.frame_current
                self._dragged = True

                # 首次按下左键时快照并清空选中；同一次拖拽中再次按下只换锚点
                if self._keyframe_selector is None and target_mode in {"KEYFRAMES", "BOTH"}:
                    active = context.active_object
                    anim_data = active.animation_data if active else None
                    action = anim_data.action if anim_data else None
                    if action:
                        slot = getattr(anim_data, "action_slot", None)
                        all_fcurves = list(_iter_action_fcurves(action, slot))
                        target_fcurves = get_bone_fcurves(all_fcurves, self._target_bone_names)
                        self._keyframe_selector = KeyframeRangeSelector(target_fcurves, all_fcurves)
                if self._keyframe_selector:
                    self._selected_key_count = self._keyframe_selector.set_range(
                        self._range_anchor_frame, self._range_anchor_frame
                    )
                    self._last_range_change = time.time()

                if target_mode in {"PREVIEW", "BOTH"}:
                    context.scene.use_preview_range = True
                    context.scene.frame_preview_start = self._range_anchor_frame
                    context.scene.frame_preview_end = self._range_anchor_frame

                _tag_animation_editors_redraw(context)
                self._sync_overlay(context, event)
                self._update_status(context)
                return {"RUNNING_MODAL"}

            elif event.value == "RELEASE":
                self._lmb_held = False
                self._apply_selection(context)
                _tag_animation_editors_redraw(context)
                self._sync_overlay(context, event)
                self._update_status(context)
                return {"RUNNING_MODAL"}

        # 计时器：框选区间停顿片刻后再写入关键帧选中
        if event.type == "TIMER":
            selector = self._keyframe_selector
            if selector and selector.dirty and time.time() - self._last_range_change >= _SELECTION_APPLY_DELAY:
                self._apply_selection(context)
            return {"RUNNING_MODAL"}

        # 2. 鼠标滚轮：调整灵敏度（数值为每帧像素数，向上滚越小越快）
        if event.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            scene = context.scene
            current = float(getattr(scene, "noetix_space_scrub_sensitivity", 6.0))
            factor = 1 / 1.2 if event.type == "WHEELUPMOUSE" else 1.2
            scene.noetix_space_scrub_sensitivity = max(
                _SENSITIVITY_MIN, min(_SENSITIVITY_MAX, round(current * factor, 1))
            )
            _OVERLAY["sensitivity_until"] = time.time() + _SENSITIVITY_HINT_SECONDS
            self._accumulated_dx = 0.0
            self._sync_overlay(context, event)
            self._update_status(context)
            return {"RUNNING_MODAL"}

        # 3. 鼠标移动：时间线刷帧与关键帧框选
        if event.type == "MOUSEMOVE":
            dx = event.mouse_x - self._last_x
            dy = event.mouse_y - self._last_y
            self._last_x = event.mouse_x
            self._last_y = event.mouse_y

            # 屏幕边缘穿透 (保证无限连续刷帧)
            win = context.window
            if win and win.width > 100:
                margin = 20
                if event.mouse_x >= win.width - margin:
                    win.cursor_warp(margin + 5, event.mouse_y)
                    self._last_x = margin + 5
                elif event.mouse_x <= margin:
                    win.cursor_warp(win.width - margin - 5, event.mouse_y)
                    self._last_x = win.width - margin - 5

            self._total_drag_distance += abs(dx)
            # 只有当总位移超过 10 像素时才真正判定为拖动，避免手抖
            if self._total_drag_distance >= 10 or abs(event.mouse_x - self._start_x) >= 10:
                self._dragged = True

            base_ppf = float(getattr(context.scene, "noetix_space_scrub_sensitivity", 6.0))
            if base_ppf <= 0.1:
                base_ppf = 6.0

            if event.shift and self._modifier != "SHIFT_SPACE":
                base_ppf *= 3.0
            elif event.ctrl:
                base_ppf = max(1.0, base_ppf / 2.5)

            self._accumulated_dx += dx
            frame_step = int(self._accumulated_dx / base_ppf)

            if frame_step != 0:
                self._accumulated_dx -= frame_step * base_ppf
                new_frame = context.scene.frame_current + frame_step
                context.scene.frame_set(new_frame)

                if self._lmb_held and self._range_anchor_frame is not None:
                    start_f = min(self._range_anchor_frame, new_frame)
                    end_f = max(self._range_anchor_frame, new_frame)

                    # 1) 关键帧：拖动中只计算区间，停顿或松开时再写入
                    if self._keyframe_selector and target_mode in {"KEYFRAMES", "BOTH"}:
                        self._selected_key_count = self._keyframe_selector.set_range(start_f, end_f)
                        self._last_range_change = time.time()

                    # 2) 预览范围
                    if target_mode in {"PREVIEW", "BOTH"}:
                        context.scene.use_preview_range = True
                        context.scene.frame_preview_start = start_f
                        context.scene.frame_preview_end = end_f

                    _tag_animation_editors_redraw(context)

            self._sync_overlay(context, event)
            self._update_status(context)
            return {"RUNNING_MODAL"}


        # 4. 按键释放判断完成
        is_release = False
        if self._modifier == "ALT_SPACE":
            # 释放 SPACE 或 ALT 均算完成
            if (event.type == "SPACE" and event.value == "RELEASE") or (
                event.type in {"LEFT_ALT", "RIGHT_ALT"} and event.value == "RELEASE"
            ):
                is_release = True
        elif self._modifier == "SHIFT_SPACE":
            if (event.type == "SPACE" and event.value == "RELEASE") or (
                event.type in {"LEFT_SHIFT", "RIGHT_SHIFT"} and event.value == "RELEASE"
            ):
                is_release = True
        else:  # "SPACE"
            if event.type == "SPACE" and event.value == "RELEASE":
                is_release = True

        if is_release:
            self._apply_selection(context)
            self._cleanup(context)
            _tag_animation_editors_redraw(context)
            duration = time.time() - self._start_time
            # 如果是仅空格模式，且未发生明显拖动（时间短且位移小），判定为点按，执行播放/暂停
            if self._modifier == "SPACE" and not self._dragged and not self._lmb_held:
                if duration < 0.4:
                    if not self._was_playing:
                        bpy.ops.screen.animation_play()
            return {"FINISHED"}

        # 5. 取消操作（ESC 或 右键）
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self._cleanup(context)
            if self._keyframe_selector:
                self._keyframe_selector.restore_original()
            context.scene.frame_set(self._initial_frame)
            context.scene.use_preview_range = self._initial_use_preview
            context.scene.frame_preview_start = self._initial_preview_start
            context.scene.frame_preview_end = self._initial_preview_end
            context.scene.frame_start = self._initial_frame_start
            context.scene.frame_end = self._initial_frame_end
            _tag_animation_editors_redraw(context)
            return {"CANCELLED"}

        return {"RUNNING_MODAL"}


class NME_OT_clear_preview_range(Operator):
    """关闭并清除时间线上的黄色预览选区，恢复全范围播放。"""

    bl_idname = "noetix_motion_editor.clear_preview_range"
    bl_label = "清除时间线选区"
    bl_description = "清除时间线选中的预览范围，恢复完整时间线播放"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        context.scene.use_preview_range = False
        self.report({"INFO"}, "已清除时间线预览选区")
        return {"FINISHED"}


def register_properties():
    scene_cls = bpy.types.Scene
    unregister_properties()

    scene_cls.noetix_enable_space_scrub = BoolProperty(
        name="启用时间线手势",
        description="按住快捷键移动鼠标拖动时间线，按住左键拖拽框选所选骨骼关键帧",
        default=True,
        update=_on_settings_updated,
    )

    scene_cls.noetix_space_scrub_modifier = EnumProperty(
        name="快捷键",
        description="时间线拖拽与框选的触发按键组合",
        items=[
            ("ALT_SPACE", "Alt + 空格", "【推荐】大拇指同时按下，完全不冲突原生空格播放"),
            ("SPACE", "纯空格", "轻按播放/暂停，按住拖拽时间线（已加入防手抖优化）"),
            ("SHIFT_SPACE", "Shift + 空格", "按住 Shift+空格 移动鼠标拖动时间线，+左键框选"),
        ],
        default="ALT_SPACE",
        update=_on_settings_updated,
    )

    scene_cls.noetix_space_scrub_sensitivity = FloatProperty(
        name="灵敏度",
        description="每移动一帧所需的鼠标像素数（数值越小越快，默认 6）",
        default=6.0,
        min=_SENSITIVITY_MIN,
        max=_SENSITIVITY_MAX,
    )

    scene_cls.noetix_scrub_range_target = EnumProperty(
        name="选区模式",
        description="按住快捷键+左键框选时的目标操作",
        items=[
            ("KEYFRAMES", "选中骨骼关键帧", "【推荐】直接高亮选中所选骨骼在时间线范围内的关键帧"),
            ("PREVIEW", "预览范围", "设置时间线黄色预览区间，循环播放所选范围"),
            ("BOTH", "关键帧 + 预览范围", "同时选中关键帧并设置时间线黄色预览区间"),
        ],
        default="KEYFRAMES",
    )


def unregister_properties():
    scene_cls = bpy.types.Scene
    for prop in (
        "noetix_enable_space_scrub",
        "noetix_space_scrub_modifier",
        "noetix_space_scrub_sensitivity",
        "noetix_scrub_range_target",
    ):
        if hasattr(scene_cls, prop):
            delattr(scene_cls, prop)


def register_keymaps():
    wm = getattr(bpy.context, "window_manager", None)
    if not wm:
        return
    kc = getattr(wm, "keyconfigs", None)
    if not kc or not kc.addon:
        return

    # 先清理列表及已有残留，确保幂等
    unregister_keymaps()

    # 在 3D 视图与动画时间线/Dopesheet 中注册快捷键，默认配置为 Alt+SPACE
    for km_name, space_type in (
        ("3D View", "VIEW_3D"),
        ("Dopesheet", "DOPESHEET_EDITOR"),
    ):
        km = kc.addon.keymaps.new(name=km_name, space_type=space_type)
        for old_kmi in list(km.keymap_items):
            if old_kmi.idname == NME_OT_space_scrub_timeline.bl_idname:
                try:
                    km.keymap_items.remove(old_kmi)
                except Exception:
                    pass

        kmi = km.keymap_items.new(
            NME_OT_space_scrub_timeline.bl_idname,
            type="SPACE",
            value="PRESS",
        )
        kmi.alt = True
        _ADDON_KEYMAPS.append((km, kmi))

    sync_keymaps()


def unregister_keymaps():
    _remove_overlay()
    for km, kmi in _ADDON_KEYMAPS:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _ADDON_KEYMAPS.clear()


CLASSES = (
    NME_OT_space_scrub_timeline,
    NME_OT_clear_preview_range,
)
