"""UI 层：导入 operator 与面板。

职责边界：
- 只做 文件选择 / 调用 service / 汇报结果；
- 禁止在此直接调用 importer / registry 的实现细节；
- 业务编排一律走 service.import_and_archive。
"""

import json
import hashlib
import base64
import math
import time
import zlib
from pathlib import Path

import bpy
from bpy.props import IntProperty, StringProperty
from bpy.types import Operator, Panel
from bpy_extras.io_utils import ExportHelper

from . import constants as C
from . import dependencies
from . import maintenance
from . import ik_rig
from . import ik_bake
from . import ik_auto_switch
from . import scene_tools
from . import service
from . import exporter
from . import frame_rate_tools
from . import pole_repair
from . import pole_preview
from . import local_rotation
from . import center_of_mass
from . import smpl_view
from . import bvh_batch_test
from . import preview_align
from . import motion_smooth


_ADDON_VERSION_TEXT = ".".join(str(value) for value in C.ADDON_VERSION)


def _is_imported_smpl_npz(armature):
    """判断当前可编辑骨架是否来自 SMPL-H NPZ，而不是依赖对象名称。"""
    if armature is None or armature.type != "ARMATURE":
        return False
    if armature.get("noetix_smpl_motion_path"):
        return True
    source_name = armature.get(C.SOURCE_NAME_PROP)
    source = bpy.data.objects.get(source_name) if source_name else None
    return bool(source and source.get("noetix_smpl_motion_path"))


def _animation_duration_text(armature, fps):
    """返回当前选中骨架动作的实际播放时长（含首尾关键帧）。"""
    action = armature.animation_data.action if armature and armature.animation_data else None
    if action is None or fps <= 0:
        return "当前时长：无动画"
    start, end = action.frame_range
    frame_count = max(1, math.ceil(end) - math.floor(start) + 1)
    seconds = frame_count / float(fps)
    minutes, remainder = divmod(seconds, 60.0)
    return f"当前时长：{int(minutes):02d}:{remainder:05.2f}（{frame_count} 帧）"


class _ImportBase(Operator):
    """导入通用壳：文件选择 + service 编排 + 结果汇报。子类只声明 kind 与文案。"""

    # 子类覆写：后端格式 key（对应 importer._BACKENDS）
    _kind: str = ""

    def _resolve_kind(self) -> str:
        """返回此次导入所用后端；统一导入入口会按文件扩展名分流。"""
        return self._kind

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        if not self.filepath:
            self.report({"ERROR"}, "未选择文件")
            return {"CANCELLED"}

        kind = self._resolve_kind()
        if not kind:
            self.report({"ERROR"}, "仅支持 BVH 或 FBX 文件（.bvh / .fbx）")
            return {"CANCELLED"}

        try:
            result = service.import_and_archive(context, kind, self.filepath)
        except Exception as exc:
            self.report({"ERROR"}, f"导入失败：{exc}")
            return {"CANCELLED"}

        armatures = result["sources"]
        clones = result["clones"]
        if not armatures:
            self.report({"WARNING"}, "导入完成，但未检测到新增骨架，请检查文件内容")
            return {"FINISHED"}

        lines = []
        for rep in result["reports"]:
            if "error" in rep:
                lines.append(f"{rep['source']}: 克隆失败 - {rep['error']}")
                continue
            extra = []
            if rep.get("renamed"):
                extra.append(f"改名 {rep['renamed']}")
            if rep.get("ambiguous"):
                extra.append(f"歧义透传 {sum(len(v) for v in rep['ambiguous'].values())}")
            if rep.get("transparent"):
                extra.append(f"透传 {len(rep['transparent'])}")
            if rep.get("action"):
                extra.append(f"动作 {rep['action']}")
            if rep.get("action_error"):
                extra.append(f"动作未同步({rep['action_error']})")
            tail = "；".join(extra)
            lines.append(f"{rep['clone']}: 映射 {rep['mapped']} 骨" + (f"（{tail}）" if tail else ""))

        source_names = ", ".join(obj.name for obj in armatures)
        head = f"导入完成：{len(armatures)} 套源骨架已归档到 {C.SOURCE_COLLECTION}"
        if clones:
            head += f"，生成 {len(clones)} 套归一化克隆到 {C.RIG_COLLECTION}"
        timing = result.get("timing", {})
        timing_text = (
            f"导入启动耗时：总计 {timing.get('total', 0.0):.2f}s；"
            f"文件 {timing.get('file_import', 0.0):.2f}s，"
            f"清理 {timing.get('cleanup', 0.0):.2f}s，"
            f"归档 {timing.get('archive', 0.0):.2f}s，"
            f"克隆排队 {timing.get('clone_setup', 0.0):.2f}s（动作转换后台进行）；"
            f"视图裁剪结束 {C.IMPORT_VIEW_CLIP_END:.0f}m"
        )
        self.report({"INFO"}, head + "\n" + "\n".join(lines) + "\n" + timing_text)
        return {"FINISHED"}


class NME_OT_import_motion(_ImportBase):
    bl_idname = "noetix_motion_editor.import_motion"
    bl_label = "导入FBX/BVH"
    bl_description = "导入 BVH 或 FBX 动捕文件，自动识别格式并归档源骨架"
    bl_options = {"REGISTER"}

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.bvh;*.fbx", options={"HIDDEN"})

    def _resolve_kind(self) -> str:
        suffix = Path(self.filepath).suffix.lower()
        return suffix[1:] if suffix in {".bvh", ".fbx"} else ""


class NME_OT_import_smpl_npz(_ImportBase):
    """SMPL-H 参数动画独立入口，避免与普通 NPZ 数据混淆。"""

    bl_idname = "noetix_motion_editor.import_smpl_npz"
    bl_label = "导入 SMPL NPZ"
    bl_description = "导入 SMPL-H 52 关节动作；按 NPZ 的 gender 使用项目内对应的标准模型"
    bl_options = {"REGISTER"}

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*_poses.npz;*.npz", options={"HIDDEN"})
    _kind = "smpl_npz"


# 崩溃防线：禁止在 operator.execute 栈内 disable/enable 自身插件——
# execute 返回时 Blender 会访问已被注销的 operator 实例导致崩溃（曾在
# ui.py execute return 处复现 "Blender has stopped working"）。必须让
# operator 先正常返回，再用 bpy.app.timers 延迟到下一帧执行重载。
_reload_state = {"queued": False}


def _reload_notice(message, icon):
    context = bpy.context
    if context.scene is None:
        return
    _set_ui_notice(context, message, icon)


class _ModalJobMixin:
    """把长帧循环生成器挂到模态定时器上分片执行。

    统一体验：视口逐帧实时展示、界面保持响应、输入被锁定（防止分片间隙
    的并发修改破坏采样一致性）、Esc 取消。子类在 execute 里做校验后调用
    ``_start_job``，并覆写 ``_finish_job`` /（可选）``_fail_job`` 与
    ``_cancel_job``。
    """

    _job = None
    _timer = None

    def _start_job(self, context, job):
        self._job = job
        window_manager = context.window_manager
        self._timer = window_manager.event_timer_add(0.01, window=context.window)
        window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _teardown(self, context):
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        self._job = None

    def _finish_job(self, context, result):
        return {"FINISHED"}

    def _fail_job(self, context, error):
        self.report({"ERROR"}, str(error))

    def _cancel_job(self, context):
        self.report({"WARNING"}, "已取消")

    def modal(self, context, event):
        if event.type == "ESC":
            try:
                self._job.close()
            except Exception:
                pass
            self._teardown(context)
            self._cancel_job(context)
            return {"CANCELLED"}
        if event.type != "TIMER":
            # 吞掉其它输入：分片间隙的前台修改会破坏逐帧采样的一致性。
            return {"RUNNING_MODAL"}
        deadline = time.monotonic() + 0.12
        try:
            while time.monotonic() < deadline:
                next(self._job)
        except StopIteration as stop:
            self._teardown(context)
            return self._finish_job(context, stop.value)
        except Exception as exc:
            self._teardown(context)
            self._fail_job(context, exc)
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}


def _set_ui_notice(context, message, icon="INFO", duration=4.0):
    scene = context.scene if context is not None else None
    if scene is None:
        return
    scene[C.UI_NOTICE_PROP] = message
    scene[C.UI_NOTICE_ICON_PROP] = icon
    scene[C.UI_NOTICE_EXPIRES_PROP] = time.time() + duration
    if not bpy.app.timers.is_registered(_clear_expired_ui_notice):
        bpy.app.timers.register(_clear_expired_ui_notice, first_interval=duration)


def _clear_expired_ui_notice():
    scene = bpy.context.scene
    if scene is None:
        return None
    remaining = float(scene.get(C.UI_NOTICE_EXPIRES_PROP, 0.0)) - time.time()
    if remaining > 0.0:
        return remaining
    scene.pop(C.UI_NOTICE_PROP, None)
    scene.pop(C.UI_NOTICE_ICON_PROP, None)
    scene.pop(C.UI_NOTICE_EXPIRES_PROP, None)
    return None


def _delayed_reload():
    """下一帧执行：卸载 → purge sys.modules → 重新扫描启用。

    bpy.app.timers 回调处于纯 Python 上下文，此刻没有正在执行的插件
    operator 实例，disable() 注销类不会触发崩溃。
    """
    import sys
    import addon_utils

    _reload_state["queued"] = False
    root = "noetix_motion_editor"

    try:
        addon_utils.disable(root, default_set=False)
    except Exception as exc:
        message = f"Noetix 重载失败：卸载失败：{exc}"
        print(f"[Noetix] {message}")
        _reload_notice(message, "ERROR")
        return None  # 移除 timer
    # 清空模块缓存，确保从磁盘读取最新源码
    for name in list(sys.modules):
        if name == root or name.startswith(root + "."):
            del sys.modules[name]
    # 重新扫描并启用
    try:
        addon_utils.modules(refresh=True)
        addon_utils.enable(root, default_set=False, persistent=True)
    except Exception as exc:
        # 失败时插件已不在注册表，按钮也会消失，必须给出恢复指引
        message = f"Noetix 重载失败：重新启用失败：{exc}"
        print(
            f"[Noetix] {message}（面板已卸载，请勿关闭 Blender）\n"
            f"修复源码后在 Python 控制台执行:\n"
            f"import addon_utils; addon_utils.modules(refresh=True); "
            f"addon_utils.enable('{root}', persistent=True)"
        )
        _reload_notice(message, "ERROR")
        return None
    message = "Noetix 插件已重载，已读取最新源码"
    print(f"[Noetix] {message}")
    _reload_notice(message, "CHECKMARK")
    return None  # 一次性 timer，自动移除


class NME_OT_reload_addon(Operator):
    """开发工具：卸载并重新加载本插件全部模块（软连接工作流下直接读取最新源码）。"""
    bl_idname = "noetix_motion_editor.reload_addon"
    bl_label = "重载插件 (Dev)"
    bl_description = "卸载 sys.modules 中本插件全部模块并重新加载注册，用于开发迭代"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if _reload_state["queued"]:
            self.report({"WARNING"}, "重载已在排队，请稍候")
            return {"CANCELLED"}
        _reload_state["queued"] = True
        import bpy
        bpy.app.timers.register(_delayed_reload, first_interval=0.05)
        self.report({"INFO"}, "正在重载插件…")
        return {"FINISHED"}


class NME_OT_validate_animation(_ModalJobMixin, Operator):
    """维护工具：逐帧比较当前 clone 与它的源骨架（分片执行，不冻结界面）。"""
    bl_idname = "noetix_motion_editor.validate_animation"
    bl_label = "检测当前骨架动画"
    bl_description = (
        "逐帧比较当前归一化 clone 与源骨架的世界空间骨骼姿态；"
        "分片执行不冻结界面，Esc 可取消"
    )
    bl_options = {"REGISTER"}

    def execute(self, context):
        clone = context.active_object
        if clone is None or not clone.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中需要检测的归一化 clone 骨架")
            return {"CANCELLED"}
        try:
            job = maintenance.validate_clone_animation_iter(
                context,
                clone,
                detect_bone_twist=context.scene.noetix_validate_bone_twist,
            )
        except Exception as exc:
            self.report({"ERROR"}, f"检测失败：{exc}")
            return {"CANCELLED"}
        return self._start_job(context, job)

    def _fail_job(self, context, error):
        self.report({"ERROR"}, f"检测失败：{error}")

    def _finish_job(self, context, result):
        state = "通过" if result["passed"] else "存在差异"
        summary = (
            f"{state}：{result['frames'][0]}–{result['frames'][1]} 帧，{result['bones']} 骨，"
            f"最大位移 {result['max_position']:.6g}（{result['max_position_frame']} 帧，"
            f"{result['max_position_bone']}），最大旋转 {result['max_rotation']:.6g}"
        )
        if result["bone_twist_checked"]:
            summary += (
                f"，最大自转误差 {result['max_bone_twist']:.6g}（"
                f"{result['max_bone_twist_frame']} 帧，{result['max_bone_twist_bone']}）"
            )
        self.report(
            {"INFO" if result["passed"] else "WARNING"},
            summary,
        )
        _set_ui_notice(
            context,
            f"{state}：最大位移 {result['max_position']:.6g}（{result['max_position_frame']} 帧，"
            f"{result['max_position_bone']}）",
            "CHECKMARK" if result["passed"] else "ERROR",
        )
        return {"FINISHED"}


class NME_OT_toggle_smpl_body(Operator):
    """切换 SMPL-H NPZ 人体预览的显示状态。"""

    bl_idname = "noetix_motion_editor.toggle_smpl_body"
    bl_label = "显示NPZ人体"
    bl_description = "按 NPZ 的 betas 生成并绑定预览人体（不含 DMPL 软组织形变）"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        clone = context.active_object
        if clone is None or not clone.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中由 NPZ 导入生成的归一化骨架")
            return {"CANCELLED"}
        if smpl_view.body_is_visible(clone):
            smpl_view.hide_body(clone)
            self.report({"INFO"}, "已隐藏 NPZ 人体预览")
            return {"FINISHED"}
        try:
            body, created = smpl_view.show_body(context, clone)
        except Exception as exc:
            self.report({"ERROR"}, f"显示人体失败：{exc}")
            return {"CANCELLED"}
        text = "已生成人体预览" if created else "已显示已有的人体预览"
        self.report({"INFO"}, f"{text}：{body.name}")
        return {"FINISHED"}


class NME_OT_repair_pole_points(_ModalJobMixin, Operator):
    """仅修复 Graph Editor 中当前显示的一个 Pole 的 XYZ 位置键。"""

    bl_idname = "noetix_motion_editor.repair_pole_points"
    bl_label = "修复极向点"
    bl_description = "识别极向 IK 分支翻转，按 X/Y/Z 分别删除异常位置关键帧"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        armature = context.active_object
        if armature is None or not armature.get(C.IK_RIG_FLAG):
            self.report({"ERROR"}, "请先选中已建立 IK 的归一化 clone 骨架")
            return {"CANCELLED"}
        pole = context.active_pose_bone
        if pole is None or not pole.name.startswith(ik_rig.CONTROL_PREFIX + "Pole."):
            self.report({"ERROR"}, "请先选中需要修复的极向点")
            return {"CANCELLED"}
        graph_area = next((area for area in context.screen.areas if area.type == "GRAPH_EDITOR"), None)
        if graph_area is None:
            self.report({"ERROR"}, "请先打开曲线编辑器并显示该极向点的 XYZ 位置曲线")
            return {"CANCELLED"}
        with context.temp_override(area=graph_area):
            visible = list(context.visible_fcurves)
        path = f'pose.bones["{pole.name}"].location'
        curves = [curve for curve in visible if curve.data_path == path and curve.array_index in (0, 1, 2)]
        try:
            job = pole_repair.repair_visible_pole_keys_iter(context, armature, pole.name, curves)
        except Exception as exc:
            self.report({"ERROR"}, f"修复极向点失败：{exc}")
            return {"CANCELLED"}
        return self._start_job(context, job)

    def _fail_job(self, context, error):
        self.report({"ERROR"}, f"修复极向点失败：{error}")

    def _finish_job(self, context, result):
        frames, keys = result
        message = f"已修复 {frames} 帧极向点，删除 {keys} 个位置关键帧" if frames else "极向点方向正常，未删除关键帧"
        self.report({"INFO"}, message)
        _set_ui_notice(context, message, "CHECKMARK")
        return {"FINISHED"}


class NME_OT_capture_pole_preview_point(Operator):
    """将活动骨骼头部或对象原点写入一个极向计算输入槽。"""

    bl_idname = "noetix_motion_editor.capture_pole_preview_point"
    bl_label = "获取当前位置"
    bl_description = "优先读取活动骨骼头部；对象模式下读取活动对象原点"
    bl_options = {"REGISTER"}

    point_property: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        try:
            position_name = pole_preview.capture_selected_position(context, self.point_property)
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, f"已读取 {position_name} 的位置")
        return {"FINISHED"}


class NME_OT_show_pole_preview(Operator):
    bl_idname = "noetix_motion_editor.show_pole_preview"
    bl_label = "显示极向位置"
    bl_description = "根据 A → B → C 三个世界坐标显示非破坏性的极向目标预览"
    bl_options = {"REGISTER"}

    def execute(self, context):
        try:
            preview, position = pole_preview.show_preview(context)
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _set_ui_notice(context, f"已显示极向预览：{preview.name}", "CHECKMARK")
        self.report({"INFO"}, f"极向预览位置：({position.x:.3f}, {position.y:.3f}, {position.z:.3f})")
        return {"FINISHED"}


class NME_OT_hide_pole_preview(Operator):
    bl_idname = "noetix_motion_editor.hide_pole_preview"
    bl_label = "隐藏极向预览"
    bl_description = "隐藏极向位置预览，不会删除或修改任何 IK 控制器"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if not pole_preview.hide_preview():
            self.report({"INFO"}, "当前没有极向位置预览")
            return {"CANCELLED"}
        self.report({"INFO"}, "已隐藏极向位置预览")
        return {"FINISHED"}


class NME_OT_calculate_volume_center(Operator):
    """按当前姿态的骨骼段，计算近似重心。"""

    bl_idname = "noetix_motion_editor.calculate_volume_center"
    bl_label = "计算骨骼近似重心"
    bl_description = "将骨骼视作均匀杆，按当前姿态和骨骼长度计算近似重心"
    bl_options = {"REGISTER"}

    def execute(self, context):
        try:
            result = center_of_mass.calculate_selected_bone_center(context)
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        message = f"骨骼近似重心已更新：{result['bone_count']} 根骨骼"
        _set_ui_notice(context, message, "CHECKMARK", duration=8.0)
        self.report({"INFO"}, message)
        return {"FINISHED"}


class NME_OT_hide_volume_center(Operator):
    bl_idname = "noetix_motion_editor.hide_volume_center"
    bl_label = "隐藏重心预览"
    bl_description = "隐藏独立的 COM 重心球，不影响原始目标对象"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if not center_of_mass.hide_preview():
            self.report({"INFO"}, "当前没有重心预览")
            return {"CANCELLED"}
        self.report({"INFO"}, "已隐藏重心预览")
        return {"FINISHED"}


class NME_OT_build_ik(_ModalJobMixin, Operator):
    bl_idname = "noetix_motion_editor.build_ik"
    bl_label = "一键 IK"
    bl_description = (
        "创建 IK 控制器并烘焙动作轨迹；默认启用 IK 且保持原动作。"
        "烘焙分片执行：视口逐帧实时展示、界面不冻结；期间输入被锁定"
        "以防并发修改，Esc 可取消"
    )
    # 此操作会批量重写整段控制器、机械链与 Pole 曲线；Undo 会复制整套
    # Action，长动作重复执行可迅速占满内存。它是可重复构建操作，不进 Undo。
    bl_options = {"REGISTER"}

    _armature = None
    _limbs = None
    _had_ik_rig = False

    def execute(self, context):
        armature = context.active_object
        if armature is None or not armature.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中归一化 clone 骨架")
            return {"CANCELLED"}
        # 此选项是构建参数，不能在 IK 已完成后只切换约束。纯极向路径与传统
        # 完整 MCH 路径写入的是不同的动画数据，必须在一键 IK 前确定。
        armature.data[ik_rig.PRESERVE_SOURCE_TWIST_PROP] = bool(
            context.scene.noetix_ik_preserve_source_twist
        )
        self._armature = armature
        self._had_ik_rig = bool(armature.get(C.IK_RIG_FLAG))
        try:
            self._limbs = ik_rig.build(context, armature)
        except Exception as exc:
            self.report({"ERROR"}, f"创建 IK 失败：{exc}")
            return {"CANCELLED"}
        return self._start_job(
            context, ik_bake.bake_controls_iter(context, armature, list(self._limbs))
        )

    def _rollback(self, context, message):
        if not self._had_ik_rig and self._limbs:
            try:
                ik_rig.rollback_new_build(context, self._armature, self._limbs)
                suffix = "已回滚本次创建的 IK 结构"
            except Exception as rollback_exc:
                suffix = f"回滚失败：{rollback_exc}"
        else:
            suffix = "已保留原有 IK 结构"
        _set_ui_notice(context, f"{message}；{suffix}", "ERROR")
        self.report({"ERROR"}, f"{message}；{suffix}")

    def _fail_job(self, context, error):
        self._rollback(context, f"IK 创建失败：{error}")

    def _cancel_job(self, context):
        self._rollback(context, "IK 烘焙已取消")

    def _finish_job(self, context, frames):
        # 一键 IK 已生成整段 Goal/Pole/pole_angle 曲线；立即把它们记为
        # 基线。此后即使尚未开启自动切换，用户编辑 IK 后首次开启也能
        # 精确找出受影响帧段，不必先全片 IK→FK 烘焙一次。
        _remember_ik_sync_baseline(self._armature)
        timing = json.loads(self._armature.data.get(C.IK_TIMING_PROP, "{}"))
        self.report(
            {"INFO"},
            (f"IK 完成：{frames} 帧 / {timing.get('total', 0.0):.2f}s；"
             f"求值 {timing.get('evaluate', 0.0):.2f}s，"
             f"采样 {timing.get('mechanism_and_goal', 0.0):.2f}s，"
             f"Pole {timing.get('pole', 0.0):.2f}s，"
             f"求解 {timing.get('solve', 0.0):.2f}s，"
             f"写入 {timing.get('flush', 0.0):.2f}s；"
             f"角度校正 {timing.get('pole_angle_corrections', 0)} 次，"
             f"依赖图刷新 {timing.get('depsgraph_updates', 0)} 次"),
        )
        _set_ui_notice(context, f"IK 创建完成：{frames} 帧", "CHECKMARK")
        return {"FINISHED"}


class NME_OT_ik_complete_status(Operator):
    """已建立 IK 时使用的状态按钮，避免再次触发一键重建。"""

    bl_idname = "noetix_motion_editor.ik_complete_status"
    bl_label = "已完成 IK"
    bl_description = "当前选中骨架已创建 IK 控制器和控制曲线"
    bl_options = {"REGISTER"}

    def execute(self, context):
        self.report({"INFO"}, "当前骨架已完成 IK")
        return {"FINISHED"}


_AUTO_SWITCH_RUNNING = False


class NME_OT_reset_local_rotation(Operator):
    """归零局部旋转增量输入，不修改当前骨骼。"""

    bl_idname = "noetix_motion_editor.reset_local_rotation"
    bl_label = "归零输入"
    bl_description = "将局部旋转增量输入归零，不修改骨骼"
    bl_options = {"REGISTER"}

    def execute(self, context):
        local_rotation.reset_delta(context.scene)
        return {"FINISHED"}

LIMB_LABELS = {
    "arm.L": "左-臂",
    "arm.R": "右-臂",
    "leg.L": "左-腿",
    "leg.R": "右-腿",
}


def _matrices_differ(left, right, epsilon=1.0e-7):
    if left is None or right is None:
        return left is not right
    return any(
        abs(left[row][column] - right[row][column]) > epsilon
        for row in range(4)
        for column in range(4)
    )


def _iter_action_fcurves(action):
    """兼容 Blender 4/5 的 Action 曲线读取。"""
    if action is None:
        return
    if hasattr(action, "fcurves"):
        yield from action.fcurves
        return
    for layer in action.layers:
        for strip in layer.strips:
            if hasattr(strip, "channelbags"):
                for bag in strip.channelbags:
                    yield from bag.fcurves


def _limb_curve_snapshot(armature, limb, use_ik):
    """捕获一条肢体可编辑一侧的 F-Curve 键，供切换前检测增删改。"""
    action = armature.animation_data.action if armature.animation_data else None
    if use_ik:
        prefixes = [
            f'pose.bones["{ik_rig._control_name(limb)}"]',
            f'pose.bones["{ik_rig._pole_name(limb)}"]',
            f'pose.bones["{ik_rig._mch_name(limb, 1)}"].constraints["{ik_rig.CONSTRAINT_PREFIX + limb}"]',
        ]
    else:
        prefixes = [f'pose.bones["{name}"]' for name in ik_rig.available_limbs(armature).get(limb, ())]
    snapshot = {}
    for curve in _iter_action_fcurves(action):
        if not any(curve.data_path.startswith(prefix) for prefix in prefixes):
            continue
        snapshot[(curve.data_path, curve.array_index)] = {
            int(round(point.co.x)): round(float(point.co.y), 7)
            for point in curve.keyframe_points
        }
    return snapshot


def _changed_curve_interval_frames(before, after):
    """返回键增删改影响的帧；删除键会扩展到两侧幸存键，覆盖插值区间。"""
    affected = set()
    for key in set(before) | set(after):
        old, new = before.get(key, {}), after.get(key, {})
        changed = {frame for frame in set(old) | set(new) if old.get(frame) != new.get(frame)}
        if not changed:
            continue
        first, last = min(changed), max(changed)
        # 当前曲线两侧的保留键界定删除或移动键所改变的插值范围。
        survivors = sorted(new)
        prior = [frame for frame in survivors if frame < first]
        following = [frame for frame in survivors if frame > last]
        start = prior[-1] if prior else first
        end = following[0] if following else last
        affected.update(range(start, end + 1))
    return affected


def _contiguous_frame_ranges(frames):
    """将帧集合拆成互不相连的闭区间，避免烘焙中间未改动的帧。"""
    ordered = sorted({int(frame) for frame in frames})
    if not ordered:
        return []
    ranges = []
    start = previous = ordered[0]
    for frame in ordered[1:]:
        if frame != previous + 1:
            ranges.append((start, previous))
            start = frame
        previous = frame
    ranges.append((start, previous))
    return ranges


_IK_TO_FK_SYNC_SIGNATURE = "noetix_ik_to_fk_sync_signature"
_IK_TO_FK_SYNC_SNAPSHOT = "noetix_ik_to_fk_sync_snapshot"


def _ik_curve_signature(armature):
    """返回四肢 IK 输入曲线的稳定签名，用于判断 FK 是否需要全片更新。"""
    digest = hashlib.sha256()
    for limb in sorted(ik_rig.available_limbs(armature)):
        snapshot = _limb_curve_snapshot(armature, limb, True)
        for (path, index), samples in sorted(snapshot.items()):
            digest.update(path.encode("utf-8"))
            digest.update(str(index).encode("ascii"))
            for frame, value in sorted(samples.items()):
                digest.update(f"{frame}:{value:.7f};".encode("ascii"))
    return digest.hexdigest()


def _all_ik_curve_snapshots(armature):
    return {
        limb: _limb_curve_snapshot(armature, limb, True)
        for limb in ik_rig.available_limbs(armature)
    }


def _store_ik_curve_snapshots(armature, snapshots):
    """压缩保存同步基线；避免将一长串 F-Curve 键直接塞进 blend 属性。"""
    payload = {
        limb: [
            [path, index, sorted(samples.items())]
            for (path, index), samples in sorted(snapshot.items())
        ]
        for limb, snapshot in snapshots.items()
    }
    raw = json.dumps(payload, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
    armature[_IK_TO_FK_SYNC_SNAPSHOT] = base64.b64encode(zlib.compress(raw, 9)).decode("ascii")


def _load_ik_curve_snapshots(armature):
    encoded = armature.get(_IK_TO_FK_SYNC_SNAPSHOT)
    if not isinstance(encoded, str) or not encoded:
        return None
    try:
        payload = json.loads(zlib.decompress(base64.b64decode(encoded)).decode("utf-8"))
        return {
            limb: {
                (path, int(index)): {int(frame): float(value) for frame, value in samples}
                for path, index, samples in entries
            }
            for limb, entries in payload.items()
        }
    except Exception:
        # 旧文件、手动删除属性或损坏快照都安全退回一次全片同步。
        return None


def _remember_ik_sync_baseline(armature):
    snapshots = _all_ik_curve_snapshots(armature)
    armature[_IK_TO_FK_SYNC_SIGNATURE] = _ik_curve_signature(armature)
    _store_ik_curve_snapshots(armature, snapshots)


def _sync_ik_animation_to_fk_if_needed(context, armature):
    """自动切换启动前，将锁定期间新做的 IK 动画一次性烘焙到 FK。"""
    signature = _ik_curve_signature(armature)
    previous_signature = armature.get(_IK_TO_FK_SYNC_SIGNATURE)
    previous = _load_ik_curve_snapshots(armature)
    if previous_signature == signature:
        # 旧版本虽已有签名但尚未保存基线时，补存即可；其签名代表此前已
        # 完成过全片同步，无须再做一次昂贵烘焙。
        if previous is None:
            _store_ik_curve_snapshots(armature, _all_ik_curve_snapshots(armature))
        return 0
    action = armature.animation_data.action if armature.animation_data else None
    if action is None:
        _remember_ik_sync_baseline(armature)
        return 0
    start, end = (int(round(value)) for value in action.frame_range)
    if end < start:
        _remember_ik_sync_baseline(armature)
        return 0
    limbs = list(ik_rig.available_limbs(armature))
    original_frame = context.scene.frame_current
    dirty_by_limb = {}
    if previous is not None:
        current = _all_ik_curve_snapshots(armature)
        for limb in limbs:
            dirty = _changed_curve_interval_frames(previous.get(limb, {}), current[limb])
            if dirty:
                dirty_by_limb[limb] = dirty
    try:
        # 旧版本可能已让个别肢体停留在 FK（正是本次要修复的情形）。先统一
        # 开启 IK，再重放当前帧的 Goal/Pole 曲线，确保下面逐帧采样的是用户
        # 在未开启自动切换期间实际编辑出的 IK，而不是过期的 FK 姿势。
        ik_rig.set_mode(context, armature, limbs, True, _sync_ik_controls=False)
        context.scene.frame_set(original_frame)
        context.view_layer.update()
        if dirty_by_limb:
            # 已有基线时只写真正受曲线改动影响的帧；每肢体一次调用，保证
            # 同一肢体的多个非连续区间仍在 IK 状态下被完整采样。
            for limb, dirty in dirty_by_limb.items():
                ik_rig.bake_ik_to_fk(context, armature, limb, dirty)
        else:
            # 首次开启或旧文件没有可比较基线，只能安全地全片统一一次。
            ik_rig.bake_all_ik_to_fk(context, armature, limbs, range(start, end + 1))
        # bake 以 FK 结束；启动自动切换前恢复统一的 IK 初始状态。
        ik_rig.set_mode(context, armature, limbs, True, _sync_ik_controls=False)
        context.scene.frame_set(original_frame)
        context.view_layer.update()
    finally:
        # 即使烘焙抛错也必须恢复用户所在帧；错误继续交给调用方报告。
        if context.scene.frame_current != original_frame:
            context.scene.frame_set(original_frame)
    _remember_ik_sync_baseline(armature)
    return sum(len(frames) for frames in dirty_by_limb.values()) if dirty_by_limb else end - start + 1


class NME_OT_auto_ik_fk(Operator):
    """参考旧插件的选择意图：选控制器即 IK，选原肢体即 FK。"""

    bl_idname = "noetix_motion_editor.auto_ik_fk"
    bl_label = "自动 IK/FK 切换"
    bl_description = "启动后：选 IK/Pole 控制器切到 IK，选原肢体骨切到 FK；Esc 停止"
    # 模态自动切换会在当前帧写关键帧，不能让一次会话积累大型 Undo 快照。
    bl_options = {"REGISTER"}

    _timer = None
    _armature_name = ""
    _last_bone = ""
    _last_selection = ()
    _pending_selection = ()
    _stable_selection_polls = 0
    _last_observed_matrix = None
    _matrix_changed_at = 0.0
    # 手动按 I 后，Blender 可能先弹出插帧菜单、再真正写入 F-Curve；因此
    # 保留一个短暂观察窗口，而不是要求控制器矩阵必须发生变化。
    _manual_key_check_until = 0.0
    # 右键/按钮/属性面板插帧不会产生统一的 Blender UI 事件；低频检查当前
    # 肢体的少量相关 F-Curve，作为与快捷键 I 无关的可靠提交入口。
    _last_curve_poll_at = 0.0
    _transform_active = False
    _last_frame = -1
    _curve_snapshots = None
    _session_limb = None
    _session_ik = False

    def _finish(self, context):
        """停止自动切换时固定为 IK，避免留下不可用的 IK 控制器。"""
        global _AUTO_SWITCH_RUNNING
        armature = bpy.data.objects.get(getattr(self, "_armature_name", ""))
        if armature is None and context.active_object is not None and context.active_object.type == "ARMATURE":
            armature = context.active_object
        if armature is not None and armature.get(C.IK_RIG_FLAG):
            try:
                # 结束一次非拖拽编辑前，先提交它已写入的关键帧改动。
                if not self._transform_active and self._session_limb is not None:
                    self._commit_edit(context, armature, self._session_limb, self._session_ik)
                # 当前 IK 曲线在本次自动会话里已按事务同步到 FK；记录签名，
                # 之后重新开启时无需重复烘焙整段动作。
                _remember_ik_sync_baseline(armature)
                # 自动模式关闭后的不变量：所有肢体都在 IK。set_mode 会从
                # 当前可见 FK 姿势吸附 Goal/Pole，但不写任何关键帧。
                armature[ik_rig.IK_ONLY_LOCK] = True
                ik_rig.set_mode(
                    context,
                    armature,
                    list(ik_rig.available_limbs(armature)),
                    True,
                    _sync_ik_controls=False,
                )
            except Exception as exc:
                self.report({"WARNING"}, f"停止自动切换时恢复 IK 失败：{exc}")
        _AUTO_SWITCH_RUNNING = False
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        context.workspace.status_text_set(None)
        return {"FINISHED"}

    def _commit_edit(self, context, armature, limb, source_ik):
        """提交一个 FK 或 IK 编辑会话，只同步该侧实际改动的帧段。"""
        snapshot_key = (limb, source_ik)
        before = self._curve_snapshots.get(snapshot_key)
        if before is None:
            self._curve_snapshots[snapshot_key] = _limb_curve_snapshot(armature, limb, source_ik)
            return False
        after = _limb_curve_snapshot(armature, limb, source_ik)
        dirty = _changed_curve_interval_frames(before, after)
        if not dirty:
            return False
        for start, end in _contiguous_frame_ranges(dirty):
            if source_ik:
                ik_rig.bake_ik_to_fk(context, armature, limb, range(start, end + 1))
            else:
                ik_rig.bake_fk_to_ik(context, armature, limb, range(start, end + 1))
        # 两个 bake 函数分别以 FK/IK 结束；无论方向都恢复用户提交前的侧。
        ik_rig.set_mode(context, armature, [limb], source_ik, _sync_ik_controls=False)
        self._curve_snapshots[(limb, True)] = _limb_curve_snapshot(armature, limb, True)
        self._curve_snapshots[(limb, False)] = _limb_curve_snapshot(armature, limb, False)
        return True

    def invoke(self, context, event):
        global _AUTO_SWITCH_RUNNING
        if _AUTO_SWITCH_RUNNING:
            return self._finish(context)
        armature = context.active_object
        if armature is None or not armature.get(C.IK_RIG_FLAG):
            self.report({"ERROR"}, "请先一键创建 IK")
            return {"CANCELLED"}
        try:
            synced_frames = _sync_ik_animation_to_fk_if_needed(context, armature)
        except Exception as exc:
            self.report({"ERROR"}, f"启动前 IK 动画同步失败：{exc}")
            return {"CANCELLED"}
        # 开启自动选择切换时，才解除 IK-only 锁。
        armature[ik_rig.IK_ONLY_LOCK] = False
        self._armature_name = armature.name
        self._last_bone = ""
        self._last_selection = ()
        self._pending_selection = ()
        self._stable_selection_polls = 0
        self._last_observed_matrix = None
        self._matrix_changed_at = 0.0
        self._manual_key_check_until = 0.0
        self._last_curve_poll_at = 0.0
        self._transform_active = False
        self._last_frame = context.scene.frame_current
        self._session_limb = None
        self._session_ik = False
        self._curve_snapshots = {
            (limb, use_ik): _limb_curve_snapshot(armature, limb, use_ik)
            for limb in ik_rig.available_limbs(armature)
            for use_ik in (False, True)
        }
        # 空闲时只需侦测选择与松手，80ms 足够及时，也避免抢占视图导航。
        self._timer = context.window_manager.event_timer_add(0.08, window=context.window)
        context.window_manager.modal_handler_add(self)
        suffix = f"；已同步 {synced_frames} 帧 IK 到 FK" if synced_frames else ""
        context.workspace.status_text_set(f"Noetix：自动 IK/FK 切换已启动，按 Esc 停止{suffix}")
        _AUTO_SWITCH_RUNNING = True
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type == "ESC" and event.value == "PRESS":
            self._transform_active = False
            return self._finish(context)
        if event.type != "TIMER":
            if event.type in {"G", "R", "S"} and event.value == "PRESS":
                self._transform_active = True
            elif event.type == "I" and event.value == "PRESS":
                # 手动插关键帧是一次明确的“提交编辑”意图。它可以发生在
                # 没有拖动控制器的情况下，不能依赖 matrix 变化来触发同步。
                self._manual_key_check_until = time.monotonic() + 1.0
            elif self._transform_active and event.type in {"LEFTMOUSE", "RET", "NUMPAD_ENTER"}:
                if event.value in {"PRESS", "RELEASE"}:
                    self._transform_active = False
                    self._matrix_changed_at = time.monotonic()
            return {"PASS_THROUGH"}
        armature = bpy.data.objects.get(self._armature_name)
        if armature is None:
            return self._finish(context)
        # 换帧绝不改写 FK 状态下的 Goal/Pole：它们由 IK F-Curve 驱动，直接
        # 写显示位置会与动画求值争夺同一 Pose，导致控制器闪烁。
        if context.scene.frame_current != self._last_frame:
            self._last_frame = context.scene.frame_current
            self._pending_selection = ()
            self._stable_selection_polls = 0
            self._last_observed_matrix = None
            self._matrix_changed_at = 0.0
            self._last_curve_poll_at = 0.0
            return {"PASS_THROUGH"}
        screen = getattr(context, "screen", None)
        if screen is not None and screen.is_animation_playing:
            self._pending_selection = ()
            self._stable_selection_polls = 0
            self._last_observed_matrix = None
            self._matrix_changed_at = 0.0
            self._last_curve_poll_at = 0.0
            return {"PASS_THROUGH"}
        active = context.active_pose_bone
        name = active.name if active is not None and active.id_data == armature else ""
        selected = tuple(sorted(
            bone.name
            for bone in (context.selected_pose_bones or ())
            if bone.id_data == armature
        ))
        selection = (name, selected)
        if selection != self._pending_selection:
            self._pending_selection = selection
            self._stable_selection_polls = 1
            self._last_observed_matrix = None
            self._matrix_changed_at = 0.0
            return {"PASS_THROUGH"}
        if self._stable_selection_polls < 2:
            self._stable_selection_polls += 1
            return {"PASS_THROUGH"}
        selection_changed = selection != self._last_selection
        if selection_changed:
            self._last_selection = selection
            self._last_bone = name
            # 离开任何一侧时先提交该侧的编辑；新选择是否也是同一肢体无关。
            if self._session_limb is not None:
                try:
                    self._commit_edit(context, armature, self._session_limb, self._session_ik)
                except Exception as exc:
                    self.report({"WARNING"}, f"自动同步 {LIMB_LABELS.get(self._session_limb, self._session_limb)} 失败：{exc}")
            self._session_limb = None
            self._last_observed_matrix = active.matrix.copy() if active is not None else None
            self._matrix_changed_at = 0.0
            self._manual_key_check_until = 0.0
            self._last_curve_poll_at = 0.0
        intent = ik_auto_switch.intent_from_bone(armature, name)
        if intent is None:
            return {"PASS_THROUGH"}
        limb, use_ik = intent
        current_ik = armature.get(ik_rig._mode_name(limb), 0.0) > 0.5
        # FK 控制器拥有烘焙后的动画 FCurve。不能在 80ms 空闲轮询里反复把
        # 它们吸附回 FK：写入的 Pose 会马上被 FCurve 求值覆盖，从而造成
        # Goal（最常见是单侧手部）来回抢位置、视觉闪烁。换帧和编辑提交后
        # 已有专门的单次刷新路径，这里保持只读。
        # 从 FK 返回 IK 时必须以当前 FK 姿态刷新 Goal/Pole。正常 IK 编辑
        # 不会设置该标记，因此重新选中控制器不会覆盖用户正在拖动的位置。
        should_switch = current_ik != use_ik
        should_refresh_ik = use_ik and ik_rig.needs_ik_refresh(armature, limb)
        if selection_changed:
            try:
                if should_switch or should_refresh_ik:
                    ik_rig.set_mode(context, armature, [limb], use_ik)
                # 进入新侧后的快照就是下一次编辑事务的基线。
                self._curve_snapshots[(limb, use_ik)] = _limb_curve_snapshot(armature, limb, use_ik)
                self._session_limb = limb
                self._session_ik = use_ik
            except Exception as exc:
                self.report(
                    {"WARNING"},
                    f"自动切换 {LIMB_LABELS.get(limb, limb)} 失败：{exc}",
                )
            self._last_observed_matrix = active.matrix.copy()
            self._matrix_changed_at = 0.0
            return {"PASS_THROUGH"}
        if self._transform_active:
            return {"PASS_THROUGH"}
        # 不论用户通过 I、右键菜单、时间线按钮还是属性面板插帧，最终都会
        # 写入相应 F-Curve。只轮询当前编辑肢体，不扫描整套 Action；普通
        # 情况每 0.35 秒检查一次，按 I 后的一秒内则立即检查。
        now = time.monotonic()
        manual_key_pending = now <= self._manual_key_check_until
        if not manual_key_pending:
            self._manual_key_check_until = 0.0
        interval = 0.0 if manual_key_pending else 0.35
        if (
            self._session_limb == limb
            and self._session_ik == use_ik
            and now - self._last_curve_poll_at >= interval
        ):
            self._last_curve_poll_at = now
            try:
                committed = self._commit_edit(context, armature, limb, use_ik)
                if committed:
                    self._manual_key_check_until = 0.0
                    self._last_observed_matrix = active.matrix.copy()
                    self._matrix_changed_at = 0.0
                    return {"PASS_THROUGH"}
            except Exception as exc:
                self.report({"WARNING"}, f"关键帧同步 {LIMB_LABELS.get(limb, limb)} 失败：{exc}")
                self._manual_key_check_until = 0.0
        matrix = active.matrix.copy()
        if _matrices_differ(self._last_observed_matrix, matrix):
            self._last_observed_matrix = matrix
            self._matrix_changed_at = time.monotonic()
            return {"PASS_THROUGH"}
        # 松手后提交当前编辑事务。commit 会比较进入该侧时的快照，因此只有
        # 新增、删除、移动或改值的键才会写到另一条时间线。
        if self._matrix_changed_at and time.monotonic() - self._matrix_changed_at >= 0.0:
            try:
                committed = self._commit_edit(context, armature, limb, use_ik)
            except Exception as exc:
                self.report({"WARNING"}, f"自动烘焙 {LIMB_LABELS.get(limb, limb)} 失败：{exc}")
            self._last_observed_matrix = active.matrix.copy()
            self._matrix_changed_at = 0.0
        # 不要用 setdefault(key, _limb_curve_snapshot(...))：Python 会在调用前
        # 先计算默认值，会使没有任何编辑的空闲轮询反复扫描所有 F-Curve。
        snapshot_key = (limb, use_ik)
        if snapshot_key not in self._curve_snapshots:
            self._curve_snapshots[snapshot_key] = _limb_curve_snapshot(armature, limb, use_ik)
        return {"PASS_THROUGH"}


class NME_OT_set_ik_mode(Operator):
    bl_idname = "noetix_motion_editor.set_ik_mode"
    bl_label = "切换 IK/FK"
    bl_description = "无跳变切换当前 clone 的 IK/FK；FK 转 IK 会吸附控制器"
    # 切换会吸附并写入控制器关键帧；与自动切换一致，不复制整套动画进 Undo。
    bl_options = {"REGISTER"}

    mode: StringProperty(default="IK")
    limb: StringProperty(default="all")

    def execute(self, context):
        armature = context.active_object
        if armature is None or not armature.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中归一化 clone 骨架")
            return {"CANCELLED"}
        # 关闭自动 IK/FK 即进入 IK-only 锁定状态。此时不能从面板绕过
        # 锁定切回 FK；先重新开启自动切换，才能恢复 FK 编辑入口。
        if self.mode == "FK" and armature.get(ik_rig.IK_ONLY_LOCK, False):
            self.report({"WARNING"}, "自动 IK/FK 已关闭：当前为 IK 锁定状态，请先开启自动切换")
            return {"CANCELLED"}
        try:
            limbs = list(ik_rig.available_limbs(armature)) if self.limb == "all" else [self.limb]
            # 手动进入 FK 与自动提交使用同一语义：先把当前 IK 的最终可见
            # 姿势写入 FK。尤其末端脚/手的旋转来自 Goal 的独立约束，若只
            # 关闭约束而不烘焙，会在同一帧回退到旧的 FK 旋转。
            if self.mode == "FK":
                frame = context.scene.frame_current
                for limb in limbs:
                    if armature.get(ik_rig._mode_name(limb), 0.0) > 0.5:
                        ik_rig.bake_ik_to_fk(context, armature, limb, (frame,))
            switched = ik_rig.set_mode(context, armature, limbs, self.mode == "IK")
        except Exception as exc:
            self.report({"ERROR"}, f"切换失败：{exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已切换 {len(switched)} 条肢体到 {self.mode}")
        return {"FINISHED"}


class NME_OT_smpl_preview_generate(Operator):
    bl_idname = "noetix_motion_editor.smpl_preview_generate"
    bl_label = "生成导出预览"
    bl_description = (
        "把当前激活骨架导出为 SMPL NPZ 并回导为预览骨架，自动缩放/对位到与源等大重叠；"
        "按场景帧范围生成，长动作耗时较长；重复执行会替换旧预览"
    )
    bl_options = {"REGISTER"}

    def execute(self, context):
        armature = context.active_object
        if armature is None or armature.type != "ARMATURE":
            self.report({"ERROR"}, "请先激活需要预览的骨架")
            return {"CANCELLED"}
        if _is_imported_smpl_npz(armature):
            self.report({"INFO"}, "导入的 SMPL NPZ 无需重定向预览，可直接导出 NPZ")
            return {"CANCELLED"}
        # 若用户从上一次生成的预览骨架发起操作，仍以其原始动作骨架重新
        # 计算，避免把已经重定向过一次的结果再次重定向。
        preview_owner = armature.get(preview_align.PREVIEW_TAG)
        if preview_owner:
            source = bpy.data.objects.get(preview_owner)
            if source is None or source.type != "ARMATURE":
                self.report({"ERROR"}, "该预览的源骨架已不存在，请选中原始骨架")
                return {"CANCELLED"}
            armature = source
        try:
            preview, scale = preview_align.generate_export_preview(context, armature)
        except Exception as exc:
            self.report({"ERROR"}, f"生成预览失败：{exc}")
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            f"NPZ 导出预览已生成：{preview.name}（缩放 ×{scale:.1f}，已与源骨架重叠）",
        )
        return {"FINISHED"}


class NME_OT_smpl_preview_clear(Operator):
    bl_idname = "noetix_motion_editor.smpl_preview_clear"
    bl_label = "删除预览"
    bl_description = "删除场景中的 NPZ 导出预览骨架"
    bl_options = {"REGISTER"}

    def execute(self, context):
        removed = preview_align.remove_export_preview(context)
        if not removed:
            self.report({"INFO"}, "场景中没有 NPZ 导出预览")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已删除 {removed} 个预览对象")
        return {"FINISHED"}


class NME_OT_run_bvh_batch_test(Operator):
    bl_idname = "noetix_motion_editor.run_bvh_batch_test"
    bl_label = "运行批量测试"
    bl_description = (
        "从 BVH、FBX、NPZ 测试目录抽样，逐个执行导入与三阶段导出；"
        "每次在输出目录内生成带网页报告的时间戳结果目录"
    )
    bl_options = {"REGISTER"}

    def execute(self, context):
        scene = context.scene
        try:
            log_path = bvh_batch_test.start_background_test(
                scene.noetix_batch_test_bvh_dir,
                scene.noetix_batch_test_fbx_dir,
                scene.noetix_batch_test_npz_dir,
                scene.noetix_batch_test_output_dir,
                scene.noetix_batch_test_sample_count,
            )
        except Exception as exc:
            self.report({"ERROR"}, f"批量测试启动失败：{exc}")
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            (f"批量测试已在后台启动，进度见状态栏；日志：{log_path}；"
             "完成后在本次结果目录生成 report.html"),
        )
        return {"FINISHED"}


class _ExportBase(_ModalJobMixin, Operator, ExportHelper):
    """导出文件选择壳；实际烘焙与格式调用在 exporter 模块。

    导出采样分片执行（不冻结界面，Esc 可取消）；写文件本身仍是单步。
    """

    _kind = ""
    _selected_key_segment = False

    def execute(self, context):
        armature = context.active_object
        self._redirected_from = None
        self._export_armature_name = ""
        self._baked_preview = False
        # SMPL-H 预览现在是“标准骨架 + 约束烘焙”的最终动作；确认后导出 NPZ
        # 必须直接读取它，不能再回到源 BVH/FBX 做第二次重定向。
        preview_owner = armature.get(preview_align.PREVIEW_TAG) if armature else None
        baked_preview = bool(armature and armature.get("noetix_smpl_baked_preview"))
        if preview_owner and not (self._kind == "smpl_npz" and baked_preview):
            original = bpy.data.objects.get(preview_owner)
            if original is None or original.type != "ARMATURE":
                self.report({"ERROR"}, f"预览的源骨架 {preview_owner} 已不存在，请选中要导出的骨架")
                return {"CANCELLED"}
            self._redirected_from = armature.name
            armature = original
        if armature is None or not armature.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中需要导出的归一化 clone 骨架")
            return {"CANCELLED"}
        imported_smpl = _is_imported_smpl_npz(armature)
        if (
            self._kind == "smpl_npz"
            and not baked_preview
            and not imported_smpl
            and not preview_align.has_export_preview(armature)
        ):
            self.report({"WARNING"}, "请先生成并检查 SMPL-H 导出预览，确认后再导出 NPZ")
            return {"CANCELLED"}
        try:
            if self._kind == "bvh":
                job = exporter.export_bvh_iter(context, armature, self.filepath)
            elif self._kind == "fbx":
                job = exporter.export_fbx_iter(context, armature, self.filepath)
            elif self._selected_key_segment:
                job = exporter.export_smpl_npz_selected_iter(context, armature, self.filepath)
            else:
                job = exporter.export_smpl_npz_iter(context, armature, self.filepath)
        except Exception as exc:
            self.report({"ERROR"}, f"导出失败：{exc}")
            return {"CANCELLED"}
        self._export_armature_name = armature.name
        self._baked_preview = baked_preview
        return self._start_job(context, job)

    def _fail_job(self, context, error):
        self.report({"ERROR"}, f"导出失败：{error}")

    def _cancel_job(self, context):
        self.report({"WARNING"}, "导出已取消")

    def _finish_job(self, context, result):
        if result is None or "FINISHED" not in result:
            self.report({"ERROR"}, "导出未完成")
            return {"CANCELLED"}
        message = f"{self._kind.upper()} 已导出：{self.filepath}"
        if self._redirected_from:
            message += (
                f"（检测到选中的是导出预览 {self._redirected_from}，"
                f"已按源骨架 {self._export_armature_name} 导出）"
            )
        elif self._kind == "smpl_npz" and self._baked_preview:
            message += "（已从确认的标准 SMPL-H 烘焙预览导出）"
        if self._selected_key_segment:
            message += "（已按选中关键帧片段导出）"
        self.report({"INFO"}, message)
        return {"FINISHED"}


class NME_OT_export_bvh(_ExportBase):
    bl_idname = "noetix_motion_editor.export_bvh"
    bl_label = "导出 BVH"
    bl_description = "将最终 IK/FK 姿势烘焙为纯骨架 BVH"
    filename_ext = ".bvh"
    filter_glob: StringProperty(default="*.bvh", options={"HIDDEN"})
    _kind = "bvh"


class NME_OT_export_fbx(_ExportBase):
    bl_idname = "noetix_motion_editor.export_fbx"
    bl_label = "导出 FBX"
    bl_description = "将最终 IK/FK 姿势烘焙为纯骨架 FBX（使用 Better FBX）"
    filename_ext = ".fbx"
    filter_glob: StringProperty(default="*.fbx", options={"HIDDEN"})
    _kind = "fbx"


class NME_OT_export_smpl_npz(_ExportBase):
    bl_idname = "noetix_motion_editor.export_smpl_npz"
    bl_label = "导出 NPZ"
    bl_description = "导出当前最终 IK/FK 姿态为 SMPL-H NPZ；普通 BVH/FBX 骨架自动重定向，DMPL 为零"
    filename_ext = ".npz"
    filter_glob: StringProperty(default="*.npz", options={"HIDDEN"})
    _kind = "smpl_npz"


class NME_OT_export_smpl_npz_selected(_ExportBase):
    bl_idname = "noetix_motion_editor.export_smpl_npz_selected"
    bl_label = "导出选中片段 NPZ"
    bl_description = "导出时间轴已选关键帧首尾之间的连续 SMPL-H NPZ 动作片段"
    filename_ext = ".npz"
    filter_glob: StringProperty(default="*.npz", options={"HIDDEN"})
    _kind = "smpl_npz"
    _selected_key_segment = True


class NME_OT_set_edit_frame_rate(_ModalJobMixin, Operator):
    """以较低帧率编辑，但按导入帧率交付。"""

    bl_idname = "noetix_motion_editor.set_edit_frame_rate"
    bl_label = "应用编辑帧率"
    # 动作替换是可重复执行的缓存转换；不写 Undo，避免长动作的完整副本再次
    # 占满内存。分片 job 支持 Esc，在提交前会恢复原动作。
    bl_options = {"REGISTER"}

    fps: IntProperty(name="编辑帧率", min=1, max=1000, default=30)

    def execute(self, context):
        active = context.active_object
        if active is None or active.type != "ARMATURE" or not active.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中需要编辑的归一化骨架")
            return {"CANCELLED"}
        if active.get(preview_align.PREVIEW_TAG):
            self.report({"ERROR"}, "请选中原始 BVH/FBX/NPZ 骨架调整编辑帧率，不要选导出预览")
            return {"CANCELLED"}
        if active.animation_data is None or active.animation_data.action is None:
            self.report({"ERROR"}, "当前骨架没有可编辑动作")
            return {"CANCELLED"}
        iterator = getattr(frame_rate_tools, "set_edit_fps_iter", None)
        if iterator is None:
            self.report({"ERROR"}, "帧率工具仍是旧版二进制，请重启 Blender 后再应用编辑帧率")
            return {"CANCELLED"}
        return self._start_job(
            context,
            iterator(context, active, self.fps),
        )

    def _finish_job(self, context, result):
        original_fps, edit_fps = result
        self.report(
            {"INFO"},
            f"已切换到 {edit_fps:g} FPS 编辑；导出时将自动恢复 {original_fps:g} FPS",
        )
        _set_ui_notice(context, f"编辑动作已重采样为 {edit_fps:g} FPS", "CHECKMARK")
        return {"FINISHED"}

    def _fail_job(self, context, error):
        self.report({"ERROR"}, f"应用编辑帧率失败：{error}")

    def _cancel_job(self, context):
        self.report({"WARNING"}, "已取消编辑帧率转换，原动作未改变")


class _NoetixPanel(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = C.UI_TAB_LABEL


class NME_PT_about(_NoetixPanel):
    """右侧栏最上方的品牌标题。"""

    bl_idname = "NME_PT_about"
    bl_label = f"{C.ADDON_LABEL} {_ADDON_VERSION_TEXT}"
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        active = context.active_object
        # Blender 在取消全选后仍可能保留上一个 active_object；必须同时确认
        # 它在 selected_objects 中，避免顶部状态区显示已经取消选择的旧目标。
        target_name = (
            active.name
            if active is not None and active in context.selected_objects
            else "未选择目标"
        )
        target = layout.row(align=True)
        target.label(text="目标", icon="RESTRICT_SELECT_OFF")
        target.label(text=target_name)
        # 对归一化骨架提供“低帧率编辑、原始帧率导出”的入口。普通场景
        # 仍保留 Blender 原生帧率控件，避免改变其既有工作流。
        editable = (
            active is not None
            and active in context.selected_objects
            and active.type == "ARMATURE"
            and active.get(C.CLONE_FLAG)
            and not active.get(preview_align.PREVIEW_TAG)
        )
        if editable:
            rate_box = layout.box()
            source_fps = frame_rate_tools.source_fps(context.scene, active)
            rate_box.label(text=f"导入 / 导出：{source_fps:g} FPS", icon="TIME")
            scene_fps = context.scene.render.fps / context.scene.render.fps_base
            rate_box.label(text=f"当前帧率：{scene_fps:g} FPS", icon="TIME")
            rate_box.label(text=_animation_duration_text(active, scene_fps), icon="TIME")
            row = rate_box.row(align=True)
            row.prop(context.scene, "noetix_edit_fps", text="编辑时帧率")
            apply = row.operator(NME_OT_set_edit_frame_rate.bl_idname, text="应用", icon="CHECKMARK")
            apply.fps = int(context.scene.noetix_edit_fps)
            toggles = rate_box.row(align=True)
            toggles.prop(context.scene, "noetix_timeline_auto_sync", text="自动时间线", toggle=True)
            toggles.prop(context.scene, "noetix_frame_rate_auto_sync", text="自动帧率", toggle=True)
        else:
            layout.prop(context.scene.render, "fps", text="帧率")
class NME_PT_import(_NoetixPanel):
    bl_idname = "NME_PT_import"
    bl_label = "导入"
    bl_order = 10

    def draw(self, context):
        layout = self.layout
        layout.operator(NME_OT_import_motion.bl_idname, text="导入FBX/BVH", icon="IMPORT")
        layout.operator(NME_OT_import_smpl_npz.bl_idname, text="导入SMPL NPZ", icon="ARMATURE_DATA")
        dependency_state = dependencies.status()
        if not dependency_state["bvh"]["enabled"]:
            layout.label(text="Blender 内置 BVH 功能不可用", icon="ERROR")
        if not dependency_state["better_fbx"]["installed"]:
            layout.label(text="未安装 Better FBX：FBX 功能不可用", icon="ERROR")
        elif not dependency_state["better_fbx"]["enabled"]:
            layout.label(text="Better FBX 启用失败：请在扩展中检查", icon="ERROR")


class NME_PT_ik_fk(_NoetixPanel):
    bl_idname = "NME_PT_ik_fk"
    bl_label = "IK/FK 控制"
    bl_order = 20

    def draw(self, context):
        body = self.layout
        active = context.active_object
        # Blender 取消全选后可能仍保留上一次 active_object；必须同时确认它
        # 仍处于选择集合中，避免未选中任何对象时继续显示“一键 IK”。
        if active is None or active not in context.selected_objects or not active.get(C.CLONE_FLAG):
            body.label(text="请选中支持的骨骼", icon="INFO")
            return
        try:
            limbs = ik_rig.available_limbs(active)
        except ValueError:
            body.label(text="请选中支持的骨骼", icon="INFO")
            return
        if not limbs:
            body.label(text="请选中支持的骨骼", icon="INFO")
            return
        if not active.get(C.IK_RIG_FLAG):
            # “保留原动作自转”由 Scene 属性的只读 getter 按当前来源提供默认值：
            # NPZ 默认勾选，BVH/FBX 默认不勾选。不能在 draw 中写 Scene，否则
            # Blender 会拒绝该操作并中断整个面板绘制。
            body.operator(NME_OT_build_ik.bl_idname, icon="CON_KINEMATIC")
            return
        # depress=True 会使用 Blender 主题的高亮色，直观标识这是已完成状态；
        # 改用无副作用的状态 operator，避免用户误点导致整段 IK 再次重建。
        completed = body.row()
        completed.operator(
            NME_OT_ik_complete_status.bl_idname,
            text="已完成 IK",
            icon="CHECKMARK",
            depress=True,
        )
        body.operator(
            NME_OT_auto_ik_fk.bl_idname,
            text="停止自动 IK/FK" if _AUTO_SWITCH_RUNNING else "启动自动 IK/FK",
            icon="PAUSE" if _AUTO_SWITCH_RUNNING else "PLAY",
        )
        # 关闭自动模式即为 IK-only 锁定；此时不展示不可用的 FK 切换栏，
        # 避免让界面暗示仍可手动进入 FK。
        if not _AUTO_SWITCH_RUNNING:
            return
        for limb in limbs:
            current_ik = active.get(ik_rig._mode_name(limb), 0.0) > 0.5
            row = body.row(align=True)
            row.label(text=LIMB_LABELS.get(limb, limb))
            ik_op = row.operator(NME_OT_set_ik_mode.bl_idname, text="IK", depress=current_ik)
            ik_op.mode, ik_op.limb = "IK", limb
            fk_op = row.operator(NME_OT_set_ik_mode.bl_idname, text="FK", depress=not current_ik)
            fk_op.mode, fk_op.limb = "FK", limb


class NME_PT_edit(_NoetixPanel):
    bl_idname = "NME_PT_edit"
    bl_label = "编辑"
    bl_order = 25

    def draw(self, context):
        layout = self.layout
        active = context.active_object
        if (
            active is None
            or active not in context.selected_objects
            or active.type != "ARMATURE"
            or not active.get(C.CLONE_FLAG)
        ):
            layout.label(text="请选中支持的可编辑骨骼", icon="INFO")
            return

        box = layout.box()
        box.label(text="动作平滑", icon="MOD_SMOOTH")
        params = box.column(align=True)
        params.prop(active, "noetix_smooth_cutoff", text="截止频率 (Hz)")
        params.prop(active, "noetix_smooth_max_gap", text="修补时长 (秒)")

        # 高级设置（平滑范围、边缘过渡、骨骼过滤、去尖峰、脚部轨迹与髋部补偿等）：默认折叠隐藏
        adv_row = box.row()
        adv_row.alignment = "LEFT"
        is_adv = getattr(active, "noetix_smooth_show_advanced", False)
        adv_row.prop(
            active,
            "noetix_smooth_show_advanced",
            icon="TRIA_DOWN" if is_adv else "TRIA_RIGHT",
            text="高级设置",
            emboss=False,
        )
        if is_adv:
            adv_col = box.column(align=True)
            adv_col.prop(active, "noetix_smooth_range_mode", text="平滑范围")
            if getattr(active, "noetix_smooth_range_mode", "SELECTED_KEYS") != "ALL":
                adv_col.prop(active, "noetix_smooth_blend_margin", text="边缘过渡 (帧)")

            bone_row = adv_col.row(align=True)
            bone_row.prop(active, "noetix_smooth_selected_bones_only", text="仅选中骨骼")
            if getattr(active, "noetix_smooth_selected_bones_only", True) and active.pose:
                sel_bones_count = sum(1 for pb in active.pose.bones if pb.select)
                if sel_bones_count > 0:
                    bone_row.label(text=f"({sel_bones_count} 根)", icon="BONE_DATA")
                else:
                    bone_row.label(text="(未选骨骼)", icon="ERROR")

            adv_col.prop(active, "noetix_smooth_despike")
            adv_col.prop(active, "noetix_smooth_foot_mode")
            if active.noetix_smooth_foot_mode == "TRAJECTORY":
                adv_col.prop(active, "noetix_smooth_foot_cutoff", text="脚轨迹截止 (Hz)")
            if active.noetix_smooth_foot_mode != "OFF":
                adv_col.prop(active, "noetix_smooth_hip_compensation", slider=True)

        if motion_smooth.find_layer(active)[1] is None:
            box.operator(motion_smooth.NME_OT_smooth_layer_build.bl_idname, icon="MOD_SMOOTH")
            return

        info = motion_smooth.layer_info(active)
        if info and "range_desc" in info:
            info_row = box.row()
            info_row.scale_y = 0.8
            info_row.label(text=f"层范围: {info['range_desc']}", icon="INFO")

        box.prop(active, "noetix_smooth_strength", slider=True)
        row = box.row(align=True)
        row.operator(motion_smooth.NME_OT_smooth_layer_build.bl_idname, text="重新计算", icon="FILE_REFRESH")
        row.operator(motion_smooth.NME_OT_smooth_layer_apply.bl_idname, text="应用", icon="CHECKMARK")
        row.operator(motion_smooth.NME_OT_smooth_layer_remove.bl_idname, text="移除", icon="X")


class NME_PT_export(_NoetixPanel):
    bl_idname = "NME_PT_export"
    bl_label = "导出"
    bl_order = 30

    def draw(self, context):
        body = self.layout
        row = body.row(align=True)
        row.operator(NME_OT_export_bvh.bl_idname, icon="EXPORT")
        row.operator(NME_OT_export_fbx.bl_idname, icon="EXPORT")
        active = context.active_object
        if _is_imported_smpl_npz(active):
            npz_box = body.box()
            npz_box.label(text="原生 NPZ：保留原始体型与动作参数", icon="CHECKMARK")
            npz_box.operator(
                NME_OT_export_smpl_npz.bl_idname,
                text="导出完整 NPZ",
                icon="EXPORT",
            )
            npz_box.operator(
                NME_OT_export_smpl_npz_selected.bl_idname,
                text="导出选中片段 NPZ",
                icon="KEY_HLT",
            )
            npz_box.label(text="选中关键帧首尾之间会作为连续片段导出", icon="INFO")
            return
        # 普通 BVH/FBX 的“预览→NPZ”链路暂时关闭；仅保留原生 NPZ 的
        # NPZ→NPZ 导出入口。相关底层实现仍保留，后续重定向方案稳定后再开放。
        return


class NME_PT_maintenance(_NoetixPanel):
    bl_idname = "NME_PT_maintenance"
    bl_label = "维护与校验"
    bl_order = 40
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        body = self.layout
        active = context.active_object
        npz_box = body.box()
        npz_box.operator(
            NME_OT_toggle_smpl_body.bl_idname,
            text="显示NPZ人体",
            icon="OUTLINER_OB_ARMATURE",
            depress=smpl_view.body_is_visible(active),
        )

        center_box = body.box()
        center_box.label(text="人体近似重心", icon="ARMATURE_DATA")
        center_box.prop(context.scene, "noetix_com_live_preview", text="实时显示", toggle=True)

        test_box = body.box()
        test_open = context.scene.noetix_batch_test_panel_open
        header = test_box.row(align=True)
        header.prop(
            context.scene,
            "noetix_batch_test_panel_open",
            text="批量测试",
            icon="TRIA_DOWN" if test_open else "TRIA_RIGHT",
            emboss=False,
        )
        if bvh_batch_test.is_running():
            header.label(text="", icon="TIME")
        if test_open:
            test_box.prop(context.scene, "noetix_batch_test_bvh_dir", text="BVH 目录")
            test_box.prop(context.scene, "noetix_batch_test_fbx_dir", text="FBX 目录")
            test_box.prop(context.scene, "noetix_batch_test_npz_dir", text="NPZ 目录")
            test_box.prop(context.scene, "noetix_batch_test_output_dir", text="输出目录")
            test_box.prop(context.scene, "noetix_batch_test_sample_count", text="每格式抽取数量")
            test_box.label(text="每次创建时间戳结果，自动保留最近 3 次", icon="INFO")
            if bvh_batch_test.is_running():
                test_box.label(text="后台测试运行中…", icon="TIME")
            run_row = test_box.row()
            run_row.enabled = not bvh_batch_test.is_running()
            run_row.operator(NME_OT_run_bvh_batch_test.bl_idname, icon="PLAY")

        check_box = body.box()
        check_box.label(text="校验", icon="CHECKMARK")
        check_box.prop(context.scene, "noetix_import_rotations_as_quaternion", text="导入时使用四元数")
        check_box.prop(context.scene, "noetix_ik_preserve_source_twist", text="保留原动作自转")
        check_box.operator(NME_OT_repair_pole_points.bl_idname, icon="MODIFIER")
        check_box.prop(context.scene, "noetix_validate_bone_twist", text="检测骨骼自转")
        check_box.operator(NME_OT_validate_animation.bl_idname, icon="CHECKMARK")
        check_box.operator(NME_OT_reload_addon.bl_idname, text="重载插件（开发）", icon="FILE_REFRESH")
        notice = context.scene.get(C.UI_NOTICE_PROP)
        notice_expires = float(context.scene.get(C.UI_NOTICE_EXPIRES_PROP, 0.0))
        if notice and notice_expires > time.time():
            body.label(
                text=notice,
                icon=context.scene.get(C.UI_NOTICE_ICON_PROP, "INFO"),
            )
        if active is not None and active.get(C.CLONE_FLAG):
            bake_raw = active.data.get(C.BAKE_STATUS_PROP)
            if bake_raw:
                try:
                    bake = json.loads(bake_raw)
                    state = bake["state"]
                    if state in {"queued", "baking"}:
                        body.label(text=f"正在烘焙：{bake.get('done', 0)} / {bake.get('total', 0)} 帧", icon="TIME")
                except (TypeError, ValueError, KeyError):
                    pass


CLASSES = (
    NME_OT_import_motion,
    NME_OT_import_smpl_npz,
    NME_OT_reload_addon,
    NME_OT_build_ik,
    NME_OT_ik_complete_status,
    NME_OT_reset_local_rotation,
    NME_OT_auto_ik_fk,
    NME_OT_set_ik_mode,
    NME_OT_export_bvh,
    NME_OT_export_fbx,
    NME_OT_export_smpl_npz,
    NME_OT_export_smpl_npz_selected,
    NME_OT_set_edit_frame_rate,
    NME_OT_validate_animation,
    NME_OT_toggle_smpl_body,
    NME_OT_capture_pole_preview_point,
    NME_OT_show_pole_preview,
    NME_OT_hide_pole_preview,
    NME_OT_calculate_volume_center,
    NME_OT_hide_volume_center,
    NME_OT_repair_pole_points,
    NME_OT_smpl_preview_generate,
    NME_OT_smpl_preview_clear,
    NME_OT_run_bvh_batch_test,
    NME_PT_about,
    NME_PT_import,
    NME_PT_ik_fk,
    NME_PT_edit,
    NME_PT_export,
    NME_PT_maintenance,
)
