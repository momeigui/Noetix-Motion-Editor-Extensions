"""一键平滑 UI 与 Operator 包装层（保留原生 Python 源码以供 Blender RNA 注册）。

核心运动学、低通滤波、去尖峰与 IK 贴合算法均位于 motion_smooth_core，
并在正式发布构建中通过 Cython 编译为二进制 .pyd 机器码进行加密保护。
"""

from __future__ import annotations

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty
from bpy.types import Operator

from . import constants as C
from . import motion_smooth_core as core
from .motion_smooth_core import (
    FOOT_MODES,
    RANGE_MODES,
    LAYER_NAME,
    LAYER_PROP,
    find_layer,
    layer_info,
    sync_layer_state,
    remove_layer,
    build_layer,
    apply_layer,
    scale_layer_time,
    get_selected_keyframe_range,
    get_target_frame_range,
)


def _on_strength_updated(self, _context):
    core.sync_layer_state(self)


def _editable_armature(context):
    obj = context.active_object
    if obj is None or obj.type != "ARMATURE" or not obj.get(C.CLONE_FLAG):
        return None
    return obj


def _scene_fps(scene):
    return float(scene.render.fps / scene.render.fps_base)


class NME_OT_smooth_layer_build(Operator):
    bl_idname = "noetix_motion_editor.smooth_layer_build"
    bl_label = "一键平滑"
    bl_description = "去除短时跳变并低通平滑，结果放在 NLA 平滑层，不改动原动作"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = _editable_armature(context)
        return obj is not None and obj.animation_data is not None and obj.animation_data.action is not None

    def execute(self, context):
        obj = _editable_armature(context)
        fps = _scene_fps(context.scene)
        cutoff = float(obj.noetix_smooth_cutoff)
        if cutoff >= fps * 0.5:
            self.report({"WARNING"}, f"截止频率需低于 {fps * 0.5:.1f} Hz（当前帧率一半），本次只做去尖峰")
        range_mode = getattr(obj, "noetix_smooth_range_mode", "SELECTED_KEYS")
        blend_margin = int(getattr(obj, "noetix_smooth_blend_margin", 10))
        selected_bones_only = bool(getattr(obj, "noetix_smooth_selected_bones_only", True))

        try:
            stats = core.build_layer(
                obj, fps, cutoff, float(obj.noetix_smooth_max_gap),
                bool(obj.noetix_smooth_despike), obj.noetix_smooth_foot_mode,
                float(obj.noetix_smooth_foot_cutoff), float(obj.noetix_smooth_hip_compensation),
                range_mode=range_mode, blend_margin=blend_margin,
                selected_bones_only=selected_bones_only, context=context,
            )
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        range_desc = stats.get("range_desc", "全部帧")
        bone_info = f"，仅 {stats.get('selected_bones_count', 0)} 根骨骼" if selected_bones_only else ""
        self.report(
            {"INFO"},
            f"已生成平滑层 [{range_desc}{bone_info}]：{stats['channel_count']} 条曲线，"
            f"修补旋转 {stats['rotation_repaired']} 帧、位移 {stats['location_repaired']} 帧，"
            f"脚部 IK {stats['foot_locked']} 帧",
        )
        return {"FINISHED"}


class NME_OT_smooth_layer_apply(Operator):
    bl_idname = "noetix_motion_editor.smooth_layer_apply"
    bl_label = "应用到动作"
    bl_description = "按当前强度把平滑结果写入原动作并移除平滑层（可 Ctrl+Z 撤销）"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = _editable_armature(context)
        return obj is not None and core.find_layer(obj)[1] is not None

    def execute(self, context):
        obj = _editable_armature(context)
        try:
            count = core.apply_layer(obj)
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, f"已写入原动作：{count} 条曲线")
        return {"FINISHED"}


class NME_OT_smooth_layer_remove(Operator):
    bl_idname = "noetix_motion_editor.smooth_layer_remove"
    bl_label = "移除平滑层"
    bl_description = "删除平滑层，恢复原动作"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = _editable_armature(context)
        return obj is not None and core.find_layer(obj)[1] is not None

    def execute(self, context):
        core.remove_layer(_editable_armature(context))
        return {"FINISHED"}


CLASSES = (
    NME_OT_smooth_layer_build,
    NME_OT_smooth_layer_apply,
    NME_OT_smooth_layer_remove,
)

_PROPERTIES = (
    "noetix_smooth_range_mode",
    "noetix_smooth_blend_margin",
    "noetix_smooth_selected_bones_only",
    "noetix_smooth_strength",
    "noetix_smooth_cutoff",
    "noetix_smooth_max_gap",
    "noetix_smooth_despike",
    "noetix_smooth_foot_mode",
    "noetix_smooth_foot_cutoff",
    "noetix_smooth_hip_compensation",
    "noetix_smooth_show_advanced",
)


def register_properties():
    unregister_properties()
    obj_cls = bpy.types.Object
    obj_cls.noetix_smooth_range_mode = EnumProperty(
        name="平滑范围",
        description="选择要平滑的帧范围",
        items=RANGE_MODES,
        default="SELECTED_KEYS",
    )
    obj_cls.noetix_smooth_blend_margin = IntProperty(
        name="边缘过渡",
        description="选区首尾两端的平滑淡入淡出帧数，使用余弦平滑过渡消除交界处的卡顿与速度跳跃",
        default=10,
        min=0,
        max=50,
    )
    obj_cls.noetix_smooth_selected_bones_only = BoolProperty(
        name="仅选中骨骼",
        description="在姿态模式下仅平滑当前选中的骨骼，身体其余骨骼保持原样",
        default=True,
    )
    obj_cls.noetix_smooth_show_advanced = BoolProperty(
        name="高级设置",
        description="展开查看与调整去尖峰、脚部轨迹与髋部补偿等高级参数",
        default=False,
    )
    obj_cls.noetix_smooth_strength = FloatProperty(
        name="强度",
        description="平滑层与原动作的混合比例；0 为原动作，1 为完全平滑",
        default=1.0,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
        update=_on_strength_updated,
    )
    obj_cls.noetix_smooth_cutoff = FloatProperty(
        name="截止频率",
        description="低通截止频率（Hz），越低越平滑，快速细节也削弱得越多",
        default=2.0,
        min=0.5,
        max=60.0,
        unit="NONE",
    )
    obj_cls.noetix_smooth_max_gap = FloatProperty(
        name="修补时长",
        description="跳变修补的最长时长（秒），更长的异常段只做低通平滑",
        default=0.2,
        min=0.01,
        max=2.0,
    )
    obj_cls.noetix_smooth_foot_mode = EnumProperty(
        name="脚部",
        description="平滑后用腿部 IK 修正脚的位置，避免滑步/飘脚",
        items=FOOT_MODES,
        default="TRAJECTORY",
    )
    obj_cls.noetix_smooth_hip_compensation = FloatProperty(
        name="髋部补偿",
        description="IK 修正脚部时由髋部分担的比例；0 只靠腿部 IK，1 髋部承担全部平均偏移",
        default=0.5,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
    )
    obj_cls.noetix_smooth_foot_cutoff = FloatProperty(
        name="脚轨迹截止频率",
        description="原动作脚部轨迹只滤除高于此频率（Hz）的抖动，作为 IK 目标",
        default=3.0,
        min=0.5,
        max=60.0,
    )
    obj_cls.noetix_smooth_despike = BoolProperty(
        name="去尖峰",
        description="先检测并修补短时跳变，再做低通平滑",
        default=True,
    )


def unregister_properties():
    for prop in _PROPERTIES:
        if hasattr(bpy.types.Object, prop):
            delattr(bpy.types.Object, prop)
