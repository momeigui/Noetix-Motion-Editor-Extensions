"""场景辅助：当前骨架时间线同步与 clone/source 生命周期联动。"""

import math

import bpy
from bpy.app.handlers import persistent

from . import constants as C


_tracked_sources = set()
_cleanup_scheduled = False
_last_timeline_key = None
_UNDO_IN_PROGRESS = False


def sync_timeline_to_armature(scene, armature):
    """将场景时间线匹配到骨架当前 Action 的完整帧范围。"""
    animation = armature.animation_data
    action = animation.action if animation else None
    if action is None:
        raise ValueError("当前骨架没有绑定动作")
    start, end = action.frame_range
    scene.frame_start = math.floor(start)
    scene.frame_end = math.ceil(end)
    scene.frame_set(min(max(scene.frame_current, scene.frame_start), scene.frame_end))
    return scene.frame_start, scene.frame_end


def _clone_source_names():
    """读取当前场景仍存在的 clone → source 引用，并刷新跟踪集合。"""
    names = set()
    for obj in bpy.data.objects:
        if obj.type != "ARMATURE" or not obj.get(C.CLONE_FLAG):
            continue
        source_name = obj.get(C.SOURCE_NAME_PROP)
        if source_name:
            names.add(source_name)
            _tracked_sources.add(source_name)
    return names


def _remove_source_if_orphaned(source_name, live_sources):
    if source_name in live_sources:
        return False
    source = bpy.data.objects.get(source_name)
    if source is None or source.type != "ARMATURE" or not source.get(C.SOURCE_FLAG):
        return False
    bpy.data.objects.remove(source, do_unlink=True)
    return True


def _remove_orphan_sources():
    """在 Blender 空闲时删除孤立源骨架，不能从 depsgraph handler 直接删除。"""
    global _cleanup_scheduled
    if _UNDO_IN_PROGRESS:
        return 0.2
    try:
        live_sources = _clone_source_names()
        # 重载插件或加载旧文件时，内存中的 _tracked_sources 会为空；扫描所有
        # 被插件标记的源骨架，确保此前已被删除 clone 的遗留源也会被清理。
        managed_sources = {
            obj.name for obj in bpy.data.objects
            if obj.type == "ARMATURE" and obj.get(C.SOURCE_FLAG)
        }
        for source_name in tuple(_tracked_sources | managed_sources):
            if _remove_source_if_orphaned(source_name, live_sources):
                _tracked_sources.discard(source_name)
    finally:
        _cleanup_scheduled = False
    return None


def _sync_deleted_clones(_scene=None, _depsgraph=None):
    """依赖图回调只排队；直接移除 RNA 数据会中断当前依赖图遍历。"""
    global _cleanup_scheduled
    if _UNDO_IN_PROGRESS:
        return
    if not _cleanup_scheduled:
        _cleanup_scheduled = True
        bpy.app.timers.register(_remove_orphan_sources, first_interval=0.05)


def _sync_active_clone_timeline():
    global _last_timeline_key
    if _UNDO_IN_PROGRESS:
        return 0.2
    context = bpy.context
    scene = context.scene
    active = context.active_object
    if active is None or active.type != "ARMATURE" or not active.get(C.CLONE_FLAG):
        _last_timeline_key = None
        return 0.2
    animation = active.animation_data
    action = animation.action if animation else None
    if action is None:
        _last_timeline_key = None
        return 0.2
    key = (active.name, action.name, tuple(action.frame_range))
    if key != _last_timeline_key:
        try:
            sync_timeline_to_armature(scene, active)
        except ValueError:
            pass
        _last_timeline_key = key
    return 0.2


def register_handlers():
    if _sync_deleted_clones not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_sync_deleted_clones)
    for handlers, callback in (
        (bpy.app.handlers.undo_pre, _undo_redo_pre),
        (bpy.app.handlers.redo_pre, _undo_redo_pre),
        (bpy.app.handlers.undo_post, _undo_redo_post),
        (bpy.app.handlers.redo_post, _undo_redo_post),
    ):
        if callback not in handlers:
            handlers.append(callback)
    # addon register() 期间 bpy.data 是 _RestrictData，不能直接扫描对象；
    # 延后到 UI/data 上下文就绪后执行首次清理。
    _sync_deleted_clones()
    if not bpy.app.timers.is_registered(_sync_active_clone_timeline):
        bpy.app.timers.register(_sync_active_clone_timeline, first_interval=0.1)


def unregister_handlers():
    if _sync_deleted_clones in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_sync_deleted_clones)
    for handlers, callback in (
        (bpy.app.handlers.undo_pre, _undo_redo_pre),
        (bpy.app.handlers.redo_pre, _undo_redo_pre),
        (bpy.app.handlers.undo_post, _undo_redo_post),
        (bpy.app.handlers.redo_post, _undo_redo_post),
    ):
        while callback in handlers:
            handlers.remove(callback)
    if bpy.app.timers.is_registered(_remove_orphan_sources):
        bpy.app.timers.unregister(_remove_orphan_sources)
    if bpy.app.timers.is_registered(_sync_active_clone_timeline):
        bpy.app.timers.unregister(_sync_active_clone_timeline)
    global _cleanup_scheduled
    _cleanup_scheduled = False
    _tracked_sources.clear()
    global _last_timeline_key
    _last_timeline_key = None


@persistent
def _undo_redo_pre(*_args):
    global _UNDO_IN_PROGRESS
    _UNDO_IN_PROGRESS = True


@persistent
def _undo_redo_post(*_args):
    global _UNDO_IN_PROGRESS, _last_timeline_key
    _UNDO_IN_PROGRESS = False
    # Undo 后 clone/source 引用关系和当前 Action 都可能变化，延后重新扫描。
    _last_timeline_key = None
    _sync_deleted_clones()
