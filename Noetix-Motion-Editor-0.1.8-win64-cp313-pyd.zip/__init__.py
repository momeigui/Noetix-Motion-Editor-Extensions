"""Noetix Motion Editor — 插件入口。

本文件只做聚合注册，不含业务逻辑。分层边界见各模块 docstring：
    ui.py        UI 层：operator / panel（薄壳，只收集参数与汇报结果）
    service.py   编排层：导入流程 controller（导入→收编→归一化克隆）
    importer/    实现层：各格式 backend（仅导入并返回骨架列表）
    registry.py  收编层：源骨架归档隐藏集合 / 只读标记
    normalize.py 归一化层：标准槽位识别 + 几何孪生克隆 + 动作同步
    constants.py 常量层：集合名 / 属性名集中管理
"""

import bpy

from . import constants as C
from . import collection_tools
from . import center_of_mass
from . import dependencies
from . import pole_preview
from . import scene_tools
from .preferences import NME_AddonPreferences
from .ui import CLASSES as UI_CLASSES

bl_info = {
    "name": "Noetix Motion Editor",
    "author": "zhimei",
    # Blender 的 legacy add-on 扫描器用 AST 读取 bl_info，值必须是字面量，
    # 不能引用 constants 中的变量；否则插件可运行却不会出现在偏好设置列表。
    "version": (0, 1, 8),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Sidebar > Noetix Motion",
    "description": "动作导入、IK/FK 编辑与多格式导出",
    "category": "Animation",
}


def register():
    center_of_mass.register_properties()
    pole_preview.register_properties()
    normalize.register_handlers()
    dependency_state = dependencies.enable_available()
    for key, state in dependency_state.items():
        if state.get("builtin"):
            # Blender 内置功能无需启用插件，避免日志出现“已启用 None”。
            continue
        module_label = state["module"] or key
        if not state["installed"]:
            print(f"[Noetix] 可选依赖未安装：{module_label}（{key} 功能暂不可用）")
        elif state["enabled"]:
            print(f"[Noetix] 已启用依赖：{module_label}")
        else:
            print(f"[Noetix] 依赖启用失败：{module_label}：{state['error']}")
    for cls in (NME_AddonPreferences, *UI_CLASSES):
        # 开发重载时旧模块可能已从 sys.modules 清除，但 Blender 仍持有旧类。
        # 先按类名释放该注册项，避免 register_class(...): already registered。
        stale = getattr(bpy.types, cls.__name__, None)
        if stale is cls:
            # 插件已启用时 Blender 可能再次调用 register()；同一个类无需
            # 重复注册，否则会报 already registered as a subclass。
            continue
        if stale is not None:
            try:
                bpy.utils.unregister_class(stale)
            except RuntimeError:
                pass
        bpy.utils.register_class(cls)
    scene_tools.register_handlers()
    # 集合整理不能阻断删除 clone 后的源骨架清理监听。
    collection_tools.organize_existing_collections()


def unregister():
    scene_tools.unregister_handlers()
    normalize.unregister_handlers()
    for cls in reversed((NME_AddonPreferences, *UI_CLASSES)):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            # 已被开发重载提前注销的类无需再次处理。
            pass
    pole_preview.unregister_properties()
    center_of_mass.unregister_properties()


if __name__ == "__main__":
    register()
