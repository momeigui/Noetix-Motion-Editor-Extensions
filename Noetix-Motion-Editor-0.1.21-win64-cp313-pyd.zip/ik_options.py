"""一键 IK 的构建选项。

本模块必须保持为 Python 源码：Blender RNA 的属性 getter/setter 必须是原生
Python 回调，不能来自发布版 Pyd 中的 Cython 函数。
"""

import json

import bpy
from bpy.props import BoolProperty

from . import constants as C
from . import ik_rig


_PRESERVE_TWIST_BY_SOURCE_PROP = "noetix_ik_preserve_source_twist_by_source"


def _active_source_key():
    active = bpy.context.active_object
    if active is None or active.type != "ARMATURE" or not active.get(C.CLONE_FLAG):
        return None
    return active.get(C.SOURCE_NAME_PROP, active.name)


def _overrides(scene):
    try:
        return json.loads(scene.get(_PRESERVE_TWIST_BY_SOURCE_PROP, "{}"))
    except (TypeError, ValueError):
        return {}


def _get_preserve_source_twist(scene):
    """NPZ 默认开启，BVH/FBX 默认关闭；绘制阶段只读。"""
    source_key = _active_source_key()
    overrides = _overrides(scene)
    if source_key in overrides:
        return bool(overrides[source_key])
    active = bpy.context.active_object
    return bool(active is not None and ik_rig.source_prefers_preserved_twist(active))


def _set_preserve_source_twist(scene, value):
    """用户修改时按来源保存，不在面板 draw 阶段写入。"""
    source_key = _active_source_key()
    if source_key is None:
        return
    overrides = _overrides(scene)
    overrides[source_key] = bool(value)
    scene[_PRESERVE_TWIST_BY_SOURCE_PROP] = json.dumps(overrides, ensure_ascii=False)


def register_properties():
    bpy.types.Scene.noetix_ik_preserve_source_twist = BoolProperty(
        name="保留原动作自转",
        description=(
            "IK 输出时保留上臂/小臂、大腿/小腿原动作绕自身长度轴的旋转。"
            "NPZ 默认开启，BVH/FBX 默认关闭；仅在执行一键 IK 前生效"
        ),
        default=False,
        get=_get_preserve_source_twist,
        set=_set_preserve_source_twist,
    )


def unregister_properties():
    if hasattr(bpy.types.Scene, "noetix_ik_preserve_source_twist"):
        del bpy.types.Scene.noetix_ik_preserve_source_twist
