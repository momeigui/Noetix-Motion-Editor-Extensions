"""低帧率编辑与原始帧率交付。

编辑阶段将动作关键帧按时间比例压缩，例如 120 FPS -> 30 FPS 时缩为 1/4；
播放的实际秒数不变。导出阶段则临时恢复原始时间轴，令所有既有导出器仍按
原始采样率工作，结束后自动回到编辑视图。
"""

from contextlib import contextmanager
import math

import bpy
from bpy.props import IntProperty

from . import constants as C
from . import cleanup
from . import preview_align


def _source_for(armature):
    source_name = armature.get(C.SOURCE_NAME_PROP) if armature else None
    return bpy.data.objects.get(source_name) if source_name else None


def rate_owner(armature):
    """预览对象沿用其源 clone 的编辑速率配置。"""
    if armature is None:
        return None
    preview_source = armature.get(preview_align.PREVIEW_TAG)
    preview_owner = bpy.data.objects.get(preview_source) if preview_source else None
    return preview_owner if preview_owner is not None else armature


def source_fps(scene, armature):
    """获取导入速率，优先原生 NPZ/BVH 元数据，最后回退当前场景。"""
    owner = rate_owner(armature)
    if owner is None:
        return float(scene.render.fps / scene.render.fps_base)
    stored = owner.get(C.ORIGINAL_FPS_PROP)
    if stored is not None:
        return float(stored)
    source = _source_for(owner)
    for candidate in (owner, source):
        if candidate is None:
            continue
        value = candidate.get("noetix_smpl_fps")
        if value is not None:
            return float(value)
        frame_time = candidate.data.get(C.BVH_FRAME_TIME_PROP)
        if frame_time:
            return 1.0 / float(frame_time)
    return float(scene.render.fps / scene.render.fps_base)


def edit_fps(scene, armature):
    owner = rate_owner(armature)
    if owner is None:
        return source_fps(scene, armature)
    return float(owner.get(C.EDIT_FPS_PROP, source_fps(scene, owner)))


def is_low_rate_editing(scene, armature):
    owner = rate_owner(armature)
    if owner is None:
        return False
    return not math.isclose(
        float(owner.get(C.EDIT_TIME_SCALE_PROP, 1.0)), 1.0,
        rel_tol=1e-8, abs_tol=1e-8,
    )


def _action_fcurves(action):
    layers = getattr(action, "layers", None)
    if not layers:
        return list(action.fcurves)
    curves = []
    for layer in layers:
        for strip in layer.strips:
            for bag in strip.channelbags:
                curves.extend(bag.fcurves)
    return curves


def _scale_action_time(action, factor, pivot):
    if action is None or math.isclose(factor, 1.0, rel_tol=1e-10, abs_tol=1e-10):
        return
    for curve in _action_fcurves(action):
        for key in curve.keyframe_points:
            key.co.x = pivot + (key.co.x - pivot) * factor
            key.handle_left.x = pivot + (key.handle_left.x - pivot) * factor
            key.handle_right.x = pivot + (key.handle_right.x - pivot) * factor
        curve.update()


def _resample_action_time_iter(owner, action, current_scale, target_scale, pivot, target_fps):
    """按目标编辑帧率重采样动作，只保留可编辑的整帧关键帧。

    单纯缩放曲线时间会把 120 FPS 的键变成 0.25 帧间隔；虽然时长正确，
    但编辑时依然会看到四倍密度的关键帧。这里从现有动作求值并新建 Action，
    以目标整数帧写回曲线。末帧无法整除时保留一个端点，避免时长被截短。
    """
    if action is None:
        return None
    if current_scale <= 0.0 or target_scale <= 0.0:
        raise ValueError("编辑帧率比例必须大于零")
    source_curves = list(_action_fcurves(action))
    if not source_curves:
        return (owner, action, action)

    start, end = action.frame_range
    target_start = pivot + (start - pivot) * (target_scale / current_scale)
    target_end = pivot + (end - pivot) * (target_scale / current_scale)
    # 导入动作的起帧是整数；仍使用 ceil/floor 兼容用户移动过动作的情况。
    first = math.ceil(target_start - 1e-6)
    last = math.floor(target_end + 1e-6)
    frames = [float(frame) for frame in range(first, last + 1)]
    if not frames or not math.isclose(frames[0], target_start, abs_tol=1e-5):
        frames.insert(0, float(target_start))
    if not math.isclose(frames[-1], target_end, abs_tol=1e-5):
        frames.append(float(target_end))

    replacement = bpy.data.actions.new(f"{action.name}_edit_{int(round(target_fps))}")
    cleanup.mark_managed(replacement)
    animation = owner.animation_data_create()
    animation.action = replacement
    completed = False
    try:
        sample_scale = current_scale / target_scale
        total = len(source_curves)
        for index, curve in enumerate(source_curves, start=1):
            values = [curve.evaluate(pivot + (frame - pivot) * sample_scale) for frame in frames]
            group_name = curve.group.name if curve.group is not None else ""
            replacement_curve = replacement.fcurve_ensure_for_datablock(
                owner,
                curve.data_path,
                index=curve.array_index,
                group_name=group_name,
            )
            replacement_curve.extrapolation = curve.extrapolation
            replacement_curve.keyframe_points.add(len(frames))
            coordinates = []
            for frame, value in zip(frames, values):
                coordinates.extend((frame, value))
            replacement_curve.keyframe_points.foreach_set("co", coordinates)
            # 保持原动作的插值风格；默认导入曲线使用 AUTO_CLAMPED，能避免
            # 低采样后 Bezier 把四肢摆动过冲。
            if curve.keyframe_points:
                sample_key = curve.keyframe_points[0]
                for key in replacement_curve.keyframe_points:
                    key.interpolation = sample_key.interpolation
                    key.handle_left_type = sample_key.handle_left_type
                    key.handle_right_type = sample_key.handle_right_type
            replacement_curve.update()
            # 每条曲线后让出控制权。长动作不会再因一次性构造全部 FCurve
            # 而被 Windows 判定为未响应。
            yield {"owner": owner.name, "done": index, "total": total}
        completed = True
        return (owner, action, replacement)
    finally:
        # Esc / 异常时必须恢复旧 Action；新 Action 尚未提交，不留下半成品。
        if not completed:
            if animation.action is replacement:
                animation.action = action
            if replacement.users == 0:
                bpy.data.actions.remove(replacement)


def set_scene_fps(scene, fps):
    rounded = max(1, round(float(fps)))
    scene.render.fps = rounded
    scene.render.fps_base = rounded / float(fps)


def set_edit_fps_iter(context, armature, requested_fps):
    """分片切换编辑帧率；每条 FCurve 后 yield 一次以保持 UI 响应。"""
    if armature is None or armature.type != "ARMATURE" or not armature.get(C.CLONE_FLAG):
        raise ValueError("请先选中需要编辑的归一化骨架")
    if armature.get(preview_align.PREVIEW_TAG):
        raise ValueError("请选中原始 BVH/FBX/NPZ 骨架调整编辑帧率，不要选导出预览")
    requested_fps = float(requested_fps)
    if requested_fps <= 0:
        raise ValueError("编辑帧率必须大于零")
    scene = context.scene
    original_fps = float(armature.get(C.ORIGINAL_FPS_PROP, source_fps(scene, armature)))
    original_start = int(armature.get(C.ORIGINAL_FRAME_START_PROP, scene.frame_start))
    original_end = int(armature.get(C.ORIGINAL_FRAME_END_PROP, scene.frame_end))
    current_scale = float(armature.get(C.EDIT_TIME_SCALE_PROP, 1.0))
    target_scale = requested_fps / original_fps
    action = armature.animation_data.action if armature.animation_data else None
    if action is None:
        raise ValueError("当前骨架没有可编辑动作")
    if C.ORIGINAL_FPS_PROP not in armature:
        armature[C.ORIGINAL_FPS_PROP] = original_fps
        armature[C.ORIGINAL_FRAME_START_PROP] = original_start
        armature[C.ORIGINAL_FRAME_END_PROP] = original_end
    # IK 烘焙读取归档源骨架来反求 Goal/Pole。编辑骨架的动作已缩放而源
    # 骨架仍停在原始时间轴时，二者在同一场景帧会落到不同的动画时刻：
    # 例如 30 FPS 编辑帧 107 会错误读取原始 120 FPS 的第 107 帧，而非
    # 同一时刻的约第 425 帧。源骨架仅是内部归档采样对象，因此把它与可
    # 编辑动作同步缩放，令一键 IK、FK/IK 切换始终按同一秒数读取姿态。
    source = _source_for(armature)
    source_action = (
        source.animation_data.action
        if source is not None and source.animation_data is not None
        else None
    )
    completed = []
    finished = False
    try:
        for label, owner, owner_action, owner_scale in (
            ("编辑骨架", armature, action, current_scale),
            ("归档源骨架", source, source_action, float(source.get(C.EDIT_TIME_SCALE_PROP, 1.0)) if source is not None else 1.0),
        ):
            if owner is None or owner_action is None:
                continue
            job = _resample_action_time_iter(
                owner, owner_action, owner_scale, target_scale, original_start, requested_fps
            )
            while True:
                try:
                    progress = next(job)
                except StopIteration as stop:
                    if stop.value is not None:
                        completed.append(stop.value)
                    break
                if bpy.context.workspace is not None:
                    bpy.context.workspace.status_text_set(
                        f"正在转换{label}：{progress['done']} / {progress['total']} 条曲线（Esc 取消）"
                    )
                yield progress

        if source is not None and source_action is not None:
            source[C.EDIT_TIME_SCALE_PROP] = target_scale
            source[C.EDIT_FPS_PROP] = requested_fps
            source[C.ORIGINAL_FPS_PROP] = original_fps
            source[C.ORIGINAL_FRAME_START_PROP] = original_start
            source[C.ORIGINAL_FRAME_END_PROP] = original_end
        armature[C.EDIT_FPS_PROP] = requested_fps
        armature[C.EDIT_TIME_SCALE_PROP] = target_scale
        set_scene_fps(scene, requested_fps)
        scene.frame_start = original_start
        scene.frame_end = max(
            original_start,
            # 动作端点经缩放后可能落在非整数帧（例如 1722 @ 120 FPS
            # → 431.25 @ 30 FPS）。时间轴必须覆盖最后一个关键帧，不能用
            # round 把它截到 431，后续 IK 逐帧烘焙会遗漏尾帧。
            math.ceil(original_start + (original_end - original_start) * target_scale),
        )
        current = original_start + (scene.frame_current - original_start) * (target_scale / current_scale)
        scene.frame_set(min(max(round(current), scene.frame_start), scene.frame_end))
        context.view_layer.update()
        # 两套动作都成功替换后才释放旧数据；若用户中途 Esc，会在 finally 回滚。
        for _owner, previous_action, _replacement in completed:
            cleanup.mark_managed(previous_action)
        cleanup.purge_managed_orphans()
        finished = True
        return original_fps, requested_fps
    finally:
        if not finished:
            for owner, previous_action, replacement in reversed(completed):
                animation = owner.animation_data_create()
                if animation.action is replacement:
                    animation.action = previous_action
                if replacement is not previous_action and replacement.users == 0:
                    bpy.data.actions.remove(replacement)
        if bpy.context.workspace is not None:
            bpy.context.workspace.status_text_set(None)


def set_edit_fps(context, armature, requested_fps):
    """同步入口，供脚本和测试调用；UI 应使用分片生成器。"""
    job = set_edit_fps_iter(context, armature, requested_fps)
    try:
        while True:
            next(job)
    except StopIteration as stop:
        return stop.value
    finally:
        if bpy.context.workspace is not None:
            bpy.context.workspace.status_text_set(None)


@contextmanager
def export_at_source_rate(context, armature):
    """临时恢复导入速率和动作时间轴，供所有格式共用的交付采样。"""
    scene = context.scene
    owner = rate_owner(armature)
    if owner is None or not is_low_rate_editing(scene, owner):
        yield
        return
    action = armature.animation_data.action if armature.animation_data else None
    if action is None:
        yield
        return
    scale = float(owner.get(C.EDIT_TIME_SCALE_PROP, 1.0))
    original_fps = float(owner[C.ORIGINAL_FPS_PROP])
    original_start = int(owner[C.ORIGINAL_FRAME_START_PROP])
    original_end = int(owner[C.ORIGINAL_FRAME_END_PROP])
    previous = (
        scene.render.fps,
        scene.render.fps_base,
        scene.frame_start,
        scene.frame_end,
        scene.frame_current,
    )
    _scale_action_time(action, 1.0 / scale, original_start)
    set_scene_fps(scene, original_fps)
    scene.frame_start, scene.frame_end = original_start, original_end
    scene.frame_set(min(max(round(original_start + (previous[4] - original_start) / scale), original_start), original_end))
    context.view_layer.update()
    try:
        yield
    finally:
        _scale_action_time(action, scale, original_start)
        scene.render.fps, scene.render.fps_base = previous[0], previous[1]
        scene.frame_start, scene.frame_end = previous[2], previous[3]
        scene.frame_set(previous[4])
        context.view_layer.update()


def register_properties():
    if not hasattr(bpy.types.Scene, "noetix_edit_fps"):
        bpy.types.Scene.noetix_edit_fps = IntProperty(
            name="编辑帧率",
            description="低帧率编辑目标；应用后保持实际动画时长不变",
            default=30,
            min=1,
            max=1000,
        )


def unregister_properties():
    if hasattr(bpy.types.Scene, "noetix_edit_fps"):
        del bpy.types.Scene.noetix_edit_fps
