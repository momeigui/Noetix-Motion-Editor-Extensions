"""UI 层：导入 operator 与面板。

职责边界：
- 只做 文件选择 / 调用 service / 汇报结果；
- 禁止在此直接调用 importer / registry 的实现细节；
- 业务编排一律走 service.import_and_archive。
"""

import json
import time
from pathlib import Path

import bpy
from bpy.props import StringProperty
from bpy.types import Operator, Panel
from bpy_extras.io_utils import ExportHelper

from . import constants as C
from . import dependencies
from . import maintenance
from . import ik_rig
from . import ik_bake
from . import ik_auto_switch
from . import scene_tools
from . import service
from . import exporter
from . import pole_repair
from . import pole_preview
from . import center_of_mass
from . import smpl_view


_ADDON_VERSION_TEXT = ".".join(str(value) for value in C.ADDON_VERSION)


class _ImportBase(Operator):
    """导入通用壳：文件选择 + service 编排 + 结果汇报。子类只声明 kind 与文案。"""

    # 子类覆写：后端格式 key（对应 importer._BACKENDS）
    _kind: str = ""

    def _resolve_kind(self) -> str:
        """返回此次导入所用后端；统一导入入口会按文件扩展名分流。"""
        return self._kind

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        if not self.filepath:
            self.report({"ERROR"}, "未选择文件")
            return {"CANCELLED"}

        kind = self._resolve_kind()
        if not kind:
            self.report({"ERROR"}, "仅支持 BVH 或 FBX 文件（.bvh / .fbx）")
            return {"CANCELLED"}

        try:
            result = service.import_and_archive(context, kind, self.filepath)
        except Exception as exc:
            self.report({"ERROR"}, f"导入失败：{exc}")
            return {"CANCELLED"}

        armatures = result["sources"]
        clones = result["clones"]
        if not armatures:
            self.report({"WARNING"}, "导入完成，但未检测到新增骨架，请检查文件内容")
            return {"FINISHED"}

        lines = []
        for rep in result["reports"]:
            if "error" in rep:
                lines.append(f"{rep['source']}: 克隆失败 - {rep['error']}")
                continue
            extra = []
            if rep.get("renamed"):
                extra.append(f"改名 {rep['renamed']}")
            if rep.get("ambiguous"):
                extra.append(f"歧义透传 {sum(len(v) for v in rep['ambiguous'].values())}")
            if rep.get("transparent"):
                extra.append(f"透传 {len(rep['transparent'])}")
            if rep.get("action"):
                extra.append(f"动作 {rep['action']}")
            if rep.get("action_error"):
                extra.append(f"动作未同步({rep['action_error']})")
            tail = "；".join(extra)
            lines.append(f"{rep['clone']}: 映射 {rep['mapped']} 骨" + (f"（{tail}）" if tail else ""))

        source_names = ", ".join(obj.name for obj in armatures)
        head = f"导入完成：{len(armatures)} 套源骨架已归档到 {C.SOURCE_COLLECTION}"
        if clones:
            head += f"，生成 {len(clones)} 套归一化克隆到 {C.RIG_COLLECTION}"
        timing = result.get("timing", {})
        timing_text = (
            f"导入启动耗时：总计 {timing.get('total', 0.0):.2f}s；"
            f"文件 {timing.get('file_import', 0.0):.2f}s，"
            f"清理 {timing.get('cleanup', 0.0):.2f}s，"
            f"归档 {timing.get('archive', 0.0):.2f}s，"
            f"克隆排队 {timing.get('clone_setup', 0.0):.2f}s（动作转换后台进行）；"
            f"视图裁剪结束 {C.IMPORT_VIEW_CLIP_END:.0f}m"
        )
        self.report({"INFO"}, head + "\n" + "\n".join(lines) + "\n" + timing_text)
        return {"FINISHED"}


class NME_OT_import_motion(_ImportBase):
    bl_idname = "noetix_motion_editor.import_motion"
    bl_label = "导入FBX/BVH"
    bl_description = "导入 BVH 或 FBX 动捕文件，自动识别格式并归档源骨架"
    bl_options = {"REGISTER"}

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.bvh;*.fbx", options={"HIDDEN"})

    def _resolve_kind(self) -> str:
        suffix = Path(self.filepath).suffix.lower()
        return suffix[1:] if suffix in {".bvh", ".fbx"} else ""


class NME_OT_import_smpl_npz(_ImportBase):
    """SMPL-H 参数动画独立入口，避免与普通 NPZ 数据混淆。"""

    bl_idname = "noetix_motion_editor.import_smpl_npz"
    bl_label = "导入 SMPL NPZ"
    bl_description = "导入 SMPL-H 52 关节动作；按 NPZ 的 gender 使用项目内对应的标准模型"
    bl_options = {"REGISTER"}

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*_poses.npz;*.npz", options={"HIDDEN"})
    _kind = "smpl_npz"


# 崩溃防线：禁止在 operator.execute 栈内 disable/enable 自身插件——
# execute 返回时 Blender 会访问已被注销的 operator 实例导致崩溃（曾在
# ui.py execute return 处复现 "Blender has stopped working"）。必须让
# operator 先正常返回，再用 bpy.app.timers 延迟到下一帧执行重载。
_reload_state = {"queued": False}


def _reload_notice(message, icon):
    context = bpy.context
    if context.scene is None:
        return
    _set_ui_notice(context, message, icon)


def _set_ui_notice(context, message, icon="INFO", duration=4.0):
    scene = context.scene if context is not None else None
    if scene is None:
        return
    scene[C.UI_NOTICE_PROP] = message
    scene[C.UI_NOTICE_ICON_PROP] = icon
    scene[C.UI_NOTICE_EXPIRES_PROP] = time.time() + duration
    if not bpy.app.timers.is_registered(_clear_expired_ui_notice):
        bpy.app.timers.register(_clear_expired_ui_notice, first_interval=duration)


def _clear_expired_ui_notice():
    scene = bpy.context.scene
    if scene is None:
        return None
    remaining = float(scene.get(C.UI_NOTICE_EXPIRES_PROP, 0.0)) - time.time()
    if remaining > 0.0:
        return remaining
    scene.pop(C.UI_NOTICE_PROP, None)
    scene.pop(C.UI_NOTICE_ICON_PROP, None)
    scene.pop(C.UI_NOTICE_EXPIRES_PROP, None)
    return None


def _delayed_reload():
    """下一帧执行：卸载 → purge sys.modules → 重新扫描启用。

    bpy.app.timers 回调处于纯 Python 上下文，此刻没有正在执行的插件
    operator 实例，disable() 注销类不会触发崩溃。
    """
    import sys
    import addon_utils

    _reload_state["queued"] = False
    root = "noetix_motion_editor"

    try:
        addon_utils.disable(root, default_set=False)
    except Exception as exc:
        message = f"Noetix 重载失败：卸载失败：{exc}"
        print(f"[Noetix] {message}")
        _reload_notice(message, "ERROR")
        return None  # 移除 timer
    # 清空模块缓存，确保从磁盘读取最新源码
    for name in list(sys.modules):
        if name == root or name.startswith(root + "."):
            del sys.modules[name]
    # 重新扫描并启用
    try:
        addon_utils.modules(refresh=True)
        addon_utils.enable(root, default_set=False, persistent=True)
    except Exception as exc:
        # 失败时插件已不在注册表，按钮也会消失，必须给出恢复指引
        message = f"Noetix 重载失败：重新启用失败：{exc}"
        print(
            f"[Noetix] {message}（面板已卸载，请勿关闭 Blender）\n"
            f"修复源码后在 Python 控制台执行:\n"
            f"import addon_utils; addon_utils.modules(refresh=True); "
            f"addon_utils.enable('{root}', persistent=True)"
        )
        _reload_notice(message, "ERROR")
        return None
    message = "Noetix 插件已重载，已读取最新源码"
    print(f"[Noetix] {message}")
    _reload_notice(message, "CHECKMARK")
    return None  # 一次性 timer，自动移除


class NME_OT_reload_addon(Operator):
    """开发工具：卸载并重新加载本插件全部模块（软连接工作流下直接读取最新源码）。"""
    bl_idname = "noetix_motion_editor.reload_addon"
    bl_label = "重载插件 (Dev)"
    bl_description = "卸载 sys.modules 中本插件全部模块并重新加载注册，用于开发迭代"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if _reload_state["queued"]:
            self.report({"WARNING"}, "重载已在排队，请稍候")
            return {"CANCELLED"}
        _reload_state["queued"] = True
        import bpy
        bpy.app.timers.register(_delayed_reload, first_interval=0.05)
        self.report({"INFO"}, "正在重载插件…")
        return {"FINISHED"}


class NME_OT_validate_animation(Operator):
    """维护工具：逐帧比较当前 clone 与它的源骨架。"""
    bl_idname = "noetix_motion_editor.validate_animation"
    bl_label = "检测当前骨架动画"
    bl_description = "逐帧比较当前归一化 clone 与源骨架的世界空间骨骼姿态"
    bl_options = {"REGISTER"}

    def execute(self, context):
        clone = context.active_object
        if clone is None or not clone.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中需要检测的归一化 clone 骨架")
            return {"CANCELLED"}
        try:
            result = maintenance.validate_clone_animation(context, clone)
        except Exception as exc:
            self.report({"ERROR"}, f"检测失败：{exc}")
            return {"CANCELLED"}
        state = "通过" if result["passed"] else "存在差异"
        self.report(
            {"INFO" if result["passed"] else "WARNING"},
            f"{state}：{result['frames'][0]}–{result['frames'][1]} 帧，{result['bones']} 骨，"
            f"最大位移 {result['max_position']:.6g}，最大旋转 {result['max_rotation']:.6g}",
        )
        _set_ui_notice(
            context,
            f"{state}：最大位移 {result['max_position']:.6g}；最大旋转 {result['max_rotation']:.6g}",
            "CHECKMARK" if result["passed"] else "ERROR",
        )
        return {"FINISHED"}


class NME_OT_toggle_smpl_body(Operator):
    """切换 SMPL-H NPZ 人体预览的显示状态。"""

    bl_idname = "noetix_motion_editor.toggle_smpl_body"
    bl_label = "显示NPZ人体"
    bl_description = "按 NPZ 的 betas 生成并绑定预览人体（不含 DMPL 软组织形变）"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        clone = context.active_object
        if clone is None or not clone.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中由 NPZ 导入生成的归一化骨架")
            return {"CANCELLED"}
        if smpl_view.body_is_visible(clone):
            smpl_view.hide_body(clone)
            self.report({"INFO"}, "已隐藏 NPZ 人体预览")
            return {"FINISHED"}
        try:
            body, created = smpl_view.show_body(context, clone)
        except Exception as exc:
            self.report({"ERROR"}, f"显示人体失败：{exc}")
            return {"CANCELLED"}
        text = "已生成人体预览" if created else "已显示已有的人体预览"
        self.report({"INFO"}, f"{text}：{body.name}")
        return {"FINISHED"}


class NME_OT_repair_pole_points(Operator):
    """仅修复 Graph Editor 中当前显示的一个 Pole 的 XYZ 位置键。"""

    bl_idname = "noetix_motion_editor.repair_pole_points"
    bl_label = "修复极向点"
    bl_description = "识别极向 IK 分支翻转，按 X/Y/Z 分别删除异常位置关键帧"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        armature = context.active_object
        if armature is None or not armature.get(C.IK_RIG_FLAG):
            self.report({"ERROR"}, "请先选中已建立 IK 的归一化 clone 骨架")
            return {"CANCELLED"}
        pole = context.active_pose_bone
        if pole is None or not pole.name.startswith(ik_rig.CONTROL_PREFIX + "Pole."):
            self.report({"ERROR"}, "请先选中需要修复的极向点")
            return {"CANCELLED"}
        graph_area = next((area for area in context.screen.areas if area.type == "GRAPH_EDITOR"), None)
        if graph_area is None:
            self.report({"ERROR"}, "请先打开曲线编辑器并显示该极向点的 XYZ 位置曲线")
            return {"CANCELLED"}
        with context.temp_override(area=graph_area):
            visible = list(context.visible_fcurves)
        path = f'pose.bones["{pole.name}"].location'
        curves = [curve for curve in visible if curve.data_path == path and curve.array_index in (0, 1, 2)]
        try:
            frames, keys = pole_repair.repair_visible_pole_keys(context, armature, pole.name, curves)
        except Exception as exc:
            self.report({"ERROR"}, f"修复极向点失败：{exc}")
            return {"CANCELLED"}
        message = f"已修复 {frames} 帧极向点，删除 {keys} 个位置关键帧" if frames else "极向点方向正常，未删除关键帧"
        self.report({"INFO"}, message)
        _set_ui_notice(context, message, "CHECKMARK")
        return {"FINISHED"}


class NME_OT_capture_pole_preview_point(Operator):
    """将活动骨骼头部或对象原点写入一个极向计算输入槽。"""

    bl_idname = "noetix_motion_editor.capture_pole_preview_point"
    bl_label = "获取当前位置"
    bl_description = "优先读取活动骨骼头部；对象模式下读取活动对象原点"
    bl_options = {"REGISTER"}

    point_property: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        try:
            position_name = pole_preview.capture_selected_position(context, self.point_property)
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        self.report({"INFO"}, f"已读取 {position_name} 的位置")
        return {"FINISHED"}


class NME_OT_show_pole_preview(Operator):
    bl_idname = "noetix_motion_editor.show_pole_preview"
    bl_label = "显示极向位置"
    bl_description = "根据 A → B → C 三个世界坐标显示非破坏性的极向目标预览"
    bl_options = {"REGISTER"}

    def execute(self, context):
        try:
            preview, position = pole_preview.show_preview(context)
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _set_ui_notice(context, f"已显示极向预览：{preview.name}", "CHECKMARK")
        self.report({"INFO"}, f"极向预览位置：({position.x:.3f}, {position.y:.3f}, {position.z:.3f})")
        return {"FINISHED"}


class NME_OT_hide_pole_preview(Operator):
    bl_idname = "noetix_motion_editor.hide_pole_preview"
    bl_label = "隐藏极向预览"
    bl_description = "隐藏极向位置预览，不会删除或修改任何 IK 控制器"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if not pole_preview.hide_preview():
            self.report({"INFO"}, "当前没有极向位置预览")
            return {"CANCELLED"}
        self.report({"INFO"}, "已隐藏极向位置预览")
        return {"FINISHED"}


class NME_OT_calculate_volume_center(Operator):
    """按当前姿态的骨骼段，计算近似重心。"""

    bl_idname = "noetix_motion_editor.calculate_volume_center"
    bl_label = "计算骨骼近似重心"
    bl_description = "将骨骼视作均匀杆，按当前姿态和骨骼长度计算近似重心"
    bl_options = {"REGISTER"}

    def execute(self, context):
        try:
            result = center_of_mass.calculate_selected_bone_center(context)
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        message = f"骨骼近似重心已更新：{result['bone_count']} 根骨骼"
        _set_ui_notice(context, message, "CHECKMARK", duration=8.0)
        self.report({"INFO"}, message)
        return {"FINISHED"}


class NME_OT_hide_volume_center(Operator):
    bl_idname = "noetix_motion_editor.hide_volume_center"
    bl_label = "隐藏重心预览"
    bl_description = "隐藏独立的 COM 重心球，不影响原始目标对象"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if not center_of_mass.hide_preview():
            self.report({"INFO"}, "当前没有重心预览")
            return {"CANCELLED"}
        self.report({"INFO"}, "已隐藏重心预览")
        return {"FINISHED"}


class NME_OT_build_ik(Operator):
    bl_idname = "noetix_motion_editor.build_ik"
    bl_label = "一键 IK"
    bl_description = "创建 IK 控制器并烘焙动作轨迹；默认启用 IK 且保持原动作"
    # 此操作会批量重写整段控制器、机械链与 Pole 曲线；Undo 会复制整套
    # Action，长动作重复执行可迅速占满内存。它是可重复构建操作，不进 Undo。
    bl_options = {"REGISTER"}

    def execute(self, context):
        armature = context.active_object
        if armature is None or not armature.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中归一化 clone 骨架")
            return {"CANCELLED"}
        had_ik_rig = bool(armature.get(C.IK_RIG_FLAG))
        limbs = None
        try:
            limbs = ik_rig.build(context, armature)
            frames = ik_bake.bake_controls(context, armature, list(limbs))
        except Exception as exc:
            if not had_ik_rig and limbs:
                try:
                    ik_rig.rollback_new_build(context, armature, limbs)
                    suffix = "已回滚本次创建的 IK 结构"
                except Exception as rollback_exc:
                    suffix = f"回滚失败：{rollback_exc}"
            else:
                suffix = "已保留原有 IK 结构"
            _set_ui_notice(context, f"IK 创建失败：{exc}；{suffix}", "ERROR")
            self.report({"ERROR"}, f"创建 IK 失败：{exc}；{suffix}")
            return {"CANCELLED"}
        timing = json.loads(armature.data.get(C.IK_TIMING_PROP, "{}"))
        self.report(
            {"INFO"},
            (f"IK 完成：{frames} 帧 / {timing.get('total', 0.0):.2f}s；"
             f"求值 {timing.get('evaluate', 0.0):.2f}s，"
             f"采样 {timing.get('mechanism_and_goal', 0.0):.2f}s，"
                 f"Pole {timing.get('pole', 0.0):.2f}s，"
                 f"求解 {timing.get('solve', 0.0):.2f}s，"
                 f"写入 {timing.get('flush', 0.0):.2f}s；"
                 f"角度校正 {timing.get('pole_angle_corrections', 0)} 次，"
                 f"依赖图刷新 {timing.get('depsgraph_updates', 0)} 次")
        )
        _set_ui_notice(context, f"IK 创建完成：{frames} 帧", "CHECKMARK")
        return {"FINISHED"}


class NME_OT_ik_complete_status(Operator):
    """已建立 IK 时使用的状态按钮，避免再次触发一键重建。"""

    bl_idname = "noetix_motion_editor.ik_complete_status"
    bl_label = "已完成 IK"
    bl_description = "当前选中骨架已创建 IK 控制器和控制曲线"
    bl_options = {"REGISTER"}

    def execute(self, context):
        self.report({"INFO"}, "当前骨架已完成 IK")
        return {"FINISHED"}


_AUTO_SWITCH_RUNNING = False

LIMB_LABELS = {
    "arm.L": "左-臂",
    "arm.R": "右-臂",
    "leg.L": "左-腿",
    "leg.R": "右-腿",
}


def _matrices_differ(left, right, epsilon=1.0e-7):
    if left is None or right is None:
        return left is not right
    return any(
        abs(left[row][column] - right[row][column]) > epsilon
        for row in range(4)
        for column in range(4)
    )


def _iter_action_fcurves(action):
    """兼容 Blender 4/5 的 Action 曲线读取。"""
    if action is None:
        return
    if hasattr(action, "fcurves"):
        yield from action.fcurves
        return
    for layer in action.layers:
        for strip in layer.strips:
            if hasattr(strip, "channelbags"):
                for bag in strip.channelbags:
                    yield from bag.fcurves


def _limb_curve_snapshot(armature, limb, use_ik):
    """捕获一条肢体可编辑一侧的 F-Curve 键，供切换前检测增删改。"""
    action = armature.animation_data.action if armature.animation_data else None
    if use_ik:
        prefixes = [
            f'pose.bones["{ik_rig._control_name(limb)}"]',
            f'pose.bones["{ik_rig._pole_name(limb)}"]',
            f'pose.bones["{ik_rig._mch_name(limb, 1)}"].constraints["{ik_rig.CONSTRAINT_PREFIX + limb}"]',
        ]
    else:
        prefixes = [f'pose.bones["{name}"]' for name in ik_rig.available_limbs(armature).get(limb, ())]
    snapshot = {}
    for curve in _iter_action_fcurves(action):
        if not any(curve.data_path.startswith(prefix) for prefix in prefixes):
            continue
        snapshot[(curve.data_path, curve.array_index)] = {
            int(round(point.co.x)): round(float(point.co.y), 7)
            for point in curve.keyframe_points
        }
    return snapshot


def _changed_curve_interval_frames(before, after):
    """返回键增删改影响的帧；删除键会扩展到两侧幸存键，覆盖插值区间。"""
    affected = set()
    for key in set(before) | set(after):
        old, new = before.get(key, {}), after.get(key, {})
        changed = {frame for frame in set(old) | set(new) if old.get(frame) != new.get(frame)}
        if not changed:
            continue
        first, last = min(changed), max(changed)
        # 当前曲线两侧的保留键界定删除或移动键所改变的插值范围。
        survivors = sorted(new)
        prior = [frame for frame in survivors if frame < first]
        following = [frame for frame in survivors if frame > last]
        start = prior[-1] if prior else first
        end = following[0] if following else last
        affected.update(range(start, end + 1))
    return affected


def _contiguous_frame_ranges(frames):
    """将帧集合拆成互不相连的闭区间，避免烘焙中间未改动的帧。"""
    ordered = sorted({int(frame) for frame in frames})
    if not ordered:
        return []
    ranges = []
    start = previous = ordered[0]
    for frame in ordered[1:]:
        if frame != previous + 1:
            ranges.append((start, previous))
            start = frame
        previous = frame
    ranges.append((start, previous))
    return ranges


class NME_OT_auto_ik_fk(Operator):
    """参考旧插件的选择意图：选控制器即 IK，选原肢体即 FK。"""

    bl_idname = "noetix_motion_editor.auto_ik_fk"
    bl_label = "自动 IK/FK 切换"
    bl_description = "启动后：选 IK/Pole 控制器切到 IK，选原肢体骨切到 FK；Esc 停止"
    # 模态自动切换会在当前帧写关键帧，不能让一次会话积累大型 Undo 快照。
    bl_options = {"REGISTER"}

    _timer = None
    _armature_name = ""
    _last_bone = ""
    _last_selection = ()
    _pending_selection = ()
    _stable_selection_polls = 0
    _last_observed_matrix = None
    _matrix_changed_at = 0.0
    _transform_active = False
    _last_frame = -1
    _curve_snapshots = None
    _session_limb = None
    _session_ik = False

    def _finish(self, context):
        """停止自动切换时固定为 IK，避免留下不可用的 IK 控制器。"""
        global _AUTO_SWITCH_RUNNING
        armature = bpy.data.objects.get(getattr(self, "_armature_name", ""))
        if armature is None and context.active_object is not None and context.active_object.type == "ARMATURE":
            armature = context.active_object
        if armature is not None and armature.get(C.IK_RIG_FLAG):
            try:
                # 结束一次非拖拽编辑前，先提交它已写入的关键帧改动。
                if not self._transform_active and self._session_limb is not None:
                    self._commit_edit(context, armature, self._session_limb, self._session_ik)
                # 自动模式关闭后的不变量：所有肢体都在 IK。set_mode 会从
                # 当前可见 FK 姿势吸附 Goal/Pole，但不写任何关键帧。
                armature[ik_rig.IK_ONLY_LOCK] = True
                ik_rig.set_mode(
                    context,
                    armature,
                    list(ik_rig.available_limbs(armature)),
                    True,
                    _sync_ik_controls=False,
                )
            except Exception as exc:
                self.report({"WARNING"}, f"停止自动切换时恢复 IK 失败：{exc}")
        _AUTO_SWITCH_RUNNING = False
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        context.workspace.status_text_set(None)
        return {"FINISHED"}

    def _commit_edit(self, context, armature, limb, source_ik):
        """提交一个 FK 或 IK 编辑会话，只同步该侧实际改动的帧段。"""
        snapshot_key = (limb, source_ik)
        before = self._curve_snapshots.get(snapshot_key)
        if before is None:
            self._curve_snapshots[snapshot_key] = _limb_curve_snapshot(armature, limb, source_ik)
            return False
        after = _limb_curve_snapshot(armature, limb, source_ik)
        dirty = _changed_curve_interval_frames(before, after)
        if not dirty:
            return False
        for start, end in _contiguous_frame_ranges(dirty):
            if source_ik:
                ik_rig.bake_ik_to_fk(context, armature, limb, range(start, end + 1))
            else:
                ik_rig.bake_fk_to_ik(context, armature, limb, range(start, end + 1))
        # 两个 bake 函数分别以 FK/IK 结束；无论方向都恢复用户提交前的侧。
        ik_rig.set_mode(context, armature, [limb], source_ik, _sync_ik_controls=False)
        self._curve_snapshots[(limb, True)] = _limb_curve_snapshot(armature, limb, True)
        self._curve_snapshots[(limb, False)] = _limb_curve_snapshot(armature, limb, False)
        return True

    def invoke(self, context, event):
        global _AUTO_SWITCH_RUNNING
        if _AUTO_SWITCH_RUNNING:
            return self._finish(context)
        armature = context.active_object
        if armature is None or not armature.get(C.IK_RIG_FLAG):
            self.report({"ERROR"}, "请先一键创建 IK")
            return {"CANCELLED"}
        # 开启自动选择切换时，才解除 IK-only 锁。
        armature[ik_rig.IK_ONLY_LOCK] = False
        self._armature_name = armature.name
        self._last_bone = ""
        self._last_selection = ()
        self._pending_selection = ()
        self._stable_selection_polls = 0
        self._last_observed_matrix = None
        self._matrix_changed_at = 0.0
        self._transform_active = False
        self._last_frame = context.scene.frame_current
        self._session_limb = None
        self._session_ik = False
        self._curve_snapshots = {
            (limb, use_ik): _limb_curve_snapshot(armature, limb, use_ik)
            for limb in ik_rig.available_limbs(armature)
            for use_ik in (False, True)
        }
        # 空闲时只需侦测选择与松手，80ms 足够及时，也避免抢占视图导航。
        self._timer = context.window_manager.event_timer_add(0.08, window=context.window)
        context.window_manager.modal_handler_add(self)
        context.workspace.status_text_set("Noetix：自动 IK/FK 切换已启动，按 Esc 停止")
        _AUTO_SWITCH_RUNNING = True
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type == "ESC" and event.value == "PRESS":
            self._transform_active = False
            return self._finish(context)
        if event.type != "TIMER":
            if event.type in {"G", "R", "S"} and event.value == "PRESS":
                self._transform_active = True
            elif self._transform_active and event.type in {"LEFTMOUSE", "RET", "NUMPAD_ENTER"}:
                if event.value in {"PRESS", "RELEASE"}:
                    self._transform_active = False
                    self._matrix_changed_at = time.monotonic()
            return {"PASS_THROUGH"}
        armature = bpy.data.objects.get(self._armature_name)
        if armature is None:
            return self._finish(context)
        # 换帧只做 FK 控制器显示跟随，绝不提交/烘焙曲线。曲线的提交统一
        # 发生在松手或离开当前 FK/IK 编辑侧时。
        if context.scene.frame_current != self._last_frame:
            self._last_frame = context.scene.frame_current
            fk_limbs = [
                limb for limb in ik_rig.available_limbs(armature)
                if armature.get(ik_rig._mode_name(limb), 0.0) <= 0.5
            ]
            if fk_limbs:
                try:
                    ik_rig.refresh_ik_controls_from_fk(context, armature, fk_limbs)
                except Exception as exc:
                    self.report({"WARNING"}, f"FK 控制器显示刷新失败：{exc}")
            self._pending_selection = ()
            self._stable_selection_polls = 0
            self._last_observed_matrix = None
            self._matrix_changed_at = 0.0
            return {"PASS_THROUGH"}
        screen = getattr(context, "screen", None)
        if screen is not None and screen.is_animation_playing:
            self._pending_selection = ()
            self._stable_selection_polls = 0
            self._last_observed_matrix = None
            self._matrix_changed_at = 0.0
            return {"PASS_THROUGH"}
        active = context.active_pose_bone
        name = active.name if active is not None and active.id_data == armature else ""
        selected = tuple(sorted(
            bone.name
            for bone in (context.selected_pose_bones or ())
            if bone.id_data == armature
        ))
        selection = (name, selected)
        if selection != self._pending_selection:
            self._pending_selection = selection
            self._stable_selection_polls = 1
            self._last_observed_matrix = None
            self._matrix_changed_at = 0.0
            return {"PASS_THROUGH"}
        if self._stable_selection_polls < 2:
            self._stable_selection_polls += 1
            return {"PASS_THROUGH"}
        selection_changed = selection != self._last_selection
        if selection_changed:
            self._last_selection = selection
            self._last_bone = name
            # 离开任何一侧时先提交该侧的编辑；新选择是否也是同一肢体无关。
            if self._session_limb is not None:
                try:
                    self._commit_edit(context, armature, self._session_limb, self._session_ik)
                except Exception as exc:
                    self.report({"WARNING"}, f"自动同步 {LIMB_LABELS.get(self._session_limb, self._session_limb)} 失败：{exc}")
            self._session_limb = None
            self._last_observed_matrix = active.matrix.copy() if active is not None else None
            self._matrix_changed_at = 0.0
        intent = ik_auto_switch.intent_from_bone(armature, name)
        if intent is None:
            return {"PASS_THROUGH"}
        limb, use_ik = intent
        current_ik = armature.get(ik_rig._mode_name(limb), 0.0) > 0.5
        # 换帧或模式切换之外也可能让 FK 控制器暂时停在旧位置。空闲时只读
        # 检查当前肢体，检测到偏离才刷新；不会扫描 F-Curve 或写入关键帧。
        if not current_ik and not self._transform_active and ik_rig.fk_controls_need_refresh(armature, limb):
            try:
                ik_rig.refresh_ik_controls_from_fk(context, armature, [limb])
            except Exception as exc:
                self.report({"WARNING"}, f"FK 控制器跟踪刷新失败：{exc}")
        # 从 FK 返回 IK 时必须以当前 FK 姿态刷新 Goal/Pole。正常 IK 编辑
        # 不会设置该标记，因此重新选中控制器不会覆盖用户正在拖动的位置。
        should_switch = current_ik != use_ik
        should_refresh_ik = use_ik and ik_rig.needs_ik_refresh(armature, limb)
        if selection_changed:
            try:
                if should_switch or should_refresh_ik:
                    ik_rig.set_mode(context, armature, [limb], use_ik)
                # 进入新侧后的快照就是下一次编辑事务的基线。
                self._curve_snapshots[(limb, use_ik)] = _limb_curve_snapshot(armature, limb, use_ik)
                self._session_limb = limb
                self._session_ik = use_ik
            except Exception as exc:
                self.report(
                    {"WARNING"},
                    f"自动切换 {LIMB_LABELS.get(limb, limb)} 失败：{exc}",
                )
            self._last_observed_matrix = active.matrix.copy()
            self._matrix_changed_at = 0.0
            return {"PASS_THROUGH"}
        if self._transform_active:
            return {"PASS_THROUGH"}
        matrix = active.matrix.copy()
        if _matrices_differ(self._last_observed_matrix, matrix):
            self._last_observed_matrix = matrix
            self._matrix_changed_at = time.monotonic()
            return {"PASS_THROUGH"}
        # 松手后提交当前编辑事务。commit 会比较进入该侧时的快照，因此只有
        # 新增、删除、移动或改值的键才会写到另一条时间线。
        if self._matrix_changed_at and time.monotonic() - self._matrix_changed_at >= 0.0:
            try:
                committed = self._commit_edit(context, armature, limb, use_ik)
                if not committed and not use_ik:
                    # 即使没有 Auto Key，FK 编辑结束后控制器也要跟随当前姿势；
                    # 这只是显示对齐，不会向 IK 曲线新增任何键。
                    ik_rig.refresh_ik_controls_from_fk(context, armature, [limb])
            except Exception as exc:
                self.report({"WARNING"}, f"自动烘焙 {LIMB_LABELS.get(limb, limb)} 失败：{exc}")
            self._last_observed_matrix = active.matrix.copy()
            self._matrix_changed_at = 0.0
        # 不要用 setdefault(key, _limb_curve_snapshot(...))：Python 会在调用前
        # 先计算默认值，会使没有任何编辑的空闲轮询反复扫描所有 F-Curve。
        snapshot_key = (limb, use_ik)
        if snapshot_key not in self._curve_snapshots:
            self._curve_snapshots[snapshot_key] = _limb_curve_snapshot(armature, limb, use_ik)
        return {"PASS_THROUGH"}


class NME_OT_set_ik_mode(Operator):
    bl_idname = "noetix_motion_editor.set_ik_mode"
    bl_label = "切换 IK/FK"
    bl_description = "无跳变切换当前 clone 的 IK/FK；FK 转 IK 会吸附控制器"
    # 切换会吸附并写入控制器关键帧；与自动切换一致，不复制整套动画进 Undo。
    bl_options = {"REGISTER"}

    mode: StringProperty(default="IK")
    limb: StringProperty(default="all")

    def execute(self, context):
        armature = context.active_object
        if armature is None or not armature.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中归一化 clone 骨架")
            return {"CANCELLED"}
        # 关闭自动 IK/FK 即进入 IK-only 锁定状态。此时不能从面板绕过
        # 锁定切回 FK；先重新开启自动切换，才能恢复 FK 编辑入口。
        if self.mode == "FK" and armature.get(ik_rig.IK_ONLY_LOCK, False):
            self.report({"WARNING"}, "自动 IK/FK 已关闭：当前为 IK 锁定状态，请先开启自动切换")
            return {"CANCELLED"}
        try:
            limbs = list(ik_rig.available_limbs(armature)) if self.limb == "all" else [self.limb]
            switched = ik_rig.set_mode(context, armature, limbs, self.mode == "IK")
        except Exception as exc:
            self.report({"ERROR"}, f"切换失败：{exc}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已切换 {len(switched)} 条肢体到 {self.mode}")
        return {"FINISHED"}


class _ExportBase(Operator, ExportHelper):
    """导出文件选择壳；实际烘焙与格式调用在 exporter 模块。"""

    _kind = ""

    def execute(self, context):
        armature = context.active_object
        if armature is None or not armature.get(C.CLONE_FLAG):
            self.report({"ERROR"}, "请先选中需要导出的归一化 clone 骨架")
            return {"CANCELLED"}
        try:
            if self._kind == "bvh":
                result = exporter.export_bvh(context, armature, self.filepath)
            elif self._kind == "fbx":
                result = exporter.export_fbx(context, armature, self.filepath)
            else:
                result = exporter.export_smpl_npz(context, armature, self.filepath)
        except Exception as exc:
            self.report({"ERROR"}, f"导出失败：{exc}")
            return {"CANCELLED"}
        if "FINISHED" not in result:
            self.report({"ERROR"}, "导出未完成")
            return {"CANCELLED"}
        self.report({"INFO"}, f"{self._kind.upper()} 已导出：{self.filepath}")
        return {"FINISHED"}


class NME_OT_export_bvh(_ExportBase):
    bl_idname = "noetix_motion_editor.export_bvh"
    bl_label = "导出 BVH"
    bl_description = "将最终 IK/FK 姿势烘焙为纯骨架 BVH"
    filename_ext = ".bvh"
    filter_glob: StringProperty(default="*.bvh", options={"HIDDEN"})
    _kind = "bvh"


class NME_OT_export_fbx(_ExportBase):
    bl_idname = "noetix_motion_editor.export_fbx"
    bl_label = "导出 FBX"
    bl_description = "将最终 IK/FK 姿势烘焙为纯骨架 FBX（使用 Better FBX）"
    filename_ext = ".fbx"
    filter_glob: StringProperty(default="*.fbx", options={"HIDDEN"})
    _kind = "fbx"


class NME_OT_export_smpl_npz(_ExportBase):
    bl_idname = "noetix_motion_editor.export_smpl_npz"
    bl_label = "导出 NPZ"
    bl_description = "导出当前最终 IK/FK 姿态为 SMPL-H NPZ；普通 BVH/FBX 骨架自动重定向，DMPL 为零"
    filename_ext = ".npz"
    filter_glob: StringProperty(default="*.npz", options={"HIDDEN"})
    _kind = "smpl_npz"


class _NoetixPanel(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = C.UI_TAB_LABEL


class NME_PT_about(_NoetixPanel):
    """右侧栏最上方的品牌标题。"""

    bl_idname = "NME_PT_about"
    bl_label = f"{C.ADDON_LABEL} {_ADDON_VERSION_TEXT}"
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        active = context.active_object
        # Blender 在取消全选后仍可能保留上一个 active_object；必须同时确认
        # 它在 selected_objects 中，避免顶部状态区显示已经取消选择的旧目标。
        target_name = (
            active.name
            if active is not None and active in context.selected_objects
            else "未选择目标"
        )
        target = layout.row(align=True)
        target.label(text="目标", icon="RESTRICT_SELECT_OFF")
        target.label(text=target_name)
        # 直接绑定场景渲染帧率：用户改动后，时间线播放和导出帧时间会立刻同步。
        layout.prop(context.scene.render, "fps", text="帧率")


class NME_PT_import(_NoetixPanel):
    bl_idname = "NME_PT_import"
    bl_label = "导入"
    bl_order = 10

    def draw(self, context):
        layout = self.layout
        layout.operator(NME_OT_import_motion.bl_idname, text="导入FBX/BVH", icon="IMPORT")
        layout.operator(NME_OT_import_smpl_npz.bl_idname, text="导入SMPL NPZ", icon="ARMATURE_DATA")
        dependency_state = dependencies.status()
        if not dependency_state["bvh"]["enabled"]:
            layout.label(text="Blender 内置 BVH 功能不可用", icon="ERROR")
        if not dependency_state["better_fbx"]["installed"]:
            layout.label(text="未安装 Better FBX：FBX 功能不可用", icon="ERROR")
        elif not dependency_state["better_fbx"]["enabled"]:
            layout.label(text="Better FBX 启用失败：请在扩展中检查", icon="ERROR")


class NME_PT_ik_fk(_NoetixPanel):
    bl_idname = "NME_PT_ik_fk"
    bl_label = "IK/FK 控制"
    bl_order = 20

    def draw(self, context):
        body = self.layout
        active = context.active_object
        # Blender 取消全选后可能仍保留上一次 active_object；必须同时确认它
        # 仍处于选择集合中，避免未选中任何对象时继续显示“一键 IK”。
        if active is None or active not in context.selected_objects or not active.get(C.CLONE_FLAG):
            body.label(text="请选中支持的骨骼", icon="INFO")
            return
        try:
            limbs = ik_rig.available_limbs(active)
        except ValueError:
            body.label(text="请选中支持的骨骼", icon="INFO")
            return
        if not limbs:
            body.label(text="请选中支持的骨骼", icon="INFO")
            return
        if not active.get(C.IK_RIG_FLAG):
            body.operator(NME_OT_build_ik.bl_idname, icon="CON_KINEMATIC")
            return
        # depress=True 会使用 Blender 主题的高亮色，直观标识这是已完成状态；
        # 改用无副作用的状态 operator，避免用户误点导致整段 IK 再次重建。
        completed = body.row()
        completed.operator(
            NME_OT_ik_complete_status.bl_idname,
            text="已完成 IK",
            icon="CHECKMARK",
            depress=True,
        )
        body.operator(
            NME_OT_auto_ik_fk.bl_idname,
            text="停止自动 IK/FK" if _AUTO_SWITCH_RUNNING else "启动自动 IK/FK",
            icon="PAUSE" if _AUTO_SWITCH_RUNNING else "PLAY",
        )
        # 关闭自动模式即为 IK-only 锁定；此时不展示不可用的 FK 切换栏，
        # 避免让界面暗示仍可手动进入 FK。
        if not _AUTO_SWITCH_RUNNING:
            return
        for limb in limbs:
            current_ik = active.get(ik_rig._mode_name(limb), 0.0) > 0.5
            row = body.row(align=True)
            row.label(text=LIMB_LABELS.get(limb, limb))
            ik_op = row.operator(NME_OT_set_ik_mode.bl_idname, text="IK", depress=current_ik)
            ik_op.mode, ik_op.limb = "IK", limb
            fk_op = row.operator(NME_OT_set_ik_mode.bl_idname, text="FK", depress=not current_ik)
            fk_op.mode, fk_op.limb = "FK", limb


class NME_PT_export(_NoetixPanel):
    bl_idname = "NME_PT_export"
    bl_label = "导出"
    bl_order = 30

    def draw(self, context):
        row = self.layout.row(align=True)
        row.operator(NME_OT_export_bvh.bl_idname, icon="EXPORT")
        row.operator(NME_OT_export_fbx.bl_idname, icon="EXPORT")
        self.layout.operator(
            NME_OT_export_smpl_npz.bl_idname,
            text="导出 NPZ（仅支持 NPZ）",
            icon="EXPORT",
        )


class NME_PT_maintenance(_NoetixPanel):
    bl_idname = "NME_PT_maintenance"
    bl_label = "维护与校验"
    bl_order = 40
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        body = self.layout
        active = context.active_object
        npz_box = body.box()
        npz_box.operator(
            NME_OT_toggle_smpl_body.bl_idname,
            text="显示NPZ人体",
            icon="OUTLINER_OB_ARMATURE",
            depress=smpl_view.body_is_visible(active),
        )

        pole_box = body.box()
        pole_box.label(text="极向工具", icon="CON_KINEMATIC")
        for prop_name, label in (
            ("noetix_pole_point_start", "起点 A"),
            ("noetix_pole_point_joint", "关节 B"),
            ("noetix_pole_point_end", "末端 C"),
        ):
            row = pole_box.row(align=True)
            row.prop(context.scene, prop_name, text=label)
            capture = row.operator(NME_OT_capture_pole_preview_point.bl_idname, text="获取")
            capture.point_property = prop_name
        row = pole_box.row(align=True)
        row.operator(NME_OT_show_pole_preview.bl_idname, icon="HIDE_OFF")
        row.operator(NME_OT_hide_pole_preview.bl_idname, icon="HIDE_ON")

        center_box = body.box()
        center_box.label(text="人体近似重心", icon="ARMATURE_DATA")
        toggles = center_box.row(align=True)
        toggles.prop(context.scene, "noetix_com_live_preview", text="实时显示", toggle=True)
        toggles.prop(context.scene, "noetix_timeline_auto_sync", text="自动时间线", toggle=True)

        check_box = body.box()
        check_box.label(text="校验", icon="CHECKMARK")
        check_box.operator(NME_OT_repair_pole_points.bl_idname, icon="MODIFIER")
        check_box.operator(NME_OT_validate_animation.bl_idname, icon="CHECKMARK")
        check_box.operator(NME_OT_reload_addon.bl_idname, text="重载插件（开发）", icon="FILE_REFRESH")
        notice = context.scene.get(C.UI_NOTICE_PROP)
        notice_expires = float(context.scene.get(C.UI_NOTICE_EXPIRES_PROP, 0.0))
        if notice and notice_expires > time.time():
            body.label(
                text=notice,
                icon=context.scene.get(C.UI_NOTICE_ICON_PROP, "INFO"),
            )
        if active is not None and active.get(C.CLONE_FLAG):
            bake_raw = active.data.get(C.BAKE_STATUS_PROP)
            if bake_raw:
                try:
                    bake = json.loads(bake_raw)
                    state = bake["state"]
                    if state in {"queued", "baking"}:
                        body.label(text=f"正在烘焙：{bake.get('done', 0)} / {bake.get('total', 0)} 帧", icon="TIME")
                except (TypeError, ValueError, KeyError):
                    pass


CLASSES = (
    NME_OT_import_motion,
    NME_OT_import_smpl_npz,
    NME_OT_reload_addon,
    NME_OT_build_ik,
    NME_OT_ik_complete_status,
    NME_OT_auto_ik_fk,
    NME_OT_set_ik_mode,
    NME_OT_export_bvh,
    NME_OT_export_fbx,
    NME_OT_export_smpl_npz,
    NME_OT_validate_animation,
    NME_OT_toggle_smpl_body,
    NME_OT_capture_pole_preview_point,
    NME_OT_show_pole_preview,
    NME_OT_hide_pole_preview,
    NME_OT_calculate_volume_center,
    NME_OT_hide_volume_center,
    NME_OT_repair_pole_points,
    NME_PT_about,
    NME_PT_import,
    NME_PT_ik_fk,
    NME_PT_export,
    NME_PT_maintenance,
)
